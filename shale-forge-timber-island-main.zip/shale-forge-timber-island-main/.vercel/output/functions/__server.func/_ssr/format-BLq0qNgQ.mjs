import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime, r as Slot } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { i as cn } from "./router-BmrXQEZs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/format-BLq0qNgQ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-lg text-sm font-medium transition-[color,background-color,opacity,transform,border-color] duration-150 ease-out disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 active:scale-[0.96] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/50", {
	variants: {
		variant: {
			default: "bg-accent text-accent-fg hover:opacity-90",
			secondary: "bg-surface-2 text-fg border border-border hover:bg-surface",
			outline: "border border-border bg-transparent hover:bg-surface-2",
			ghost: "hover:bg-surface-2 text-fg",
			danger: "bg-danger text-danger-fg hover:opacity-90",
			cream: "bg-fg text-bg hover:opacity-90"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-xs",
			lg: "h-12 px-5",
			icon: "size-11",
			pad: "h-14 text-base font-semibold"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var ROLE_NAME = {
	WK: "Wicket-keeper",
	BAT: "Batter",
	AR: "All-rounder",
	BOWL: "Bowler"
};
var DISMISSAL_LABEL = {
	bowled: "Bowled",
	caught: "Caught",
	lbw: "LBW",
	run_out: "Run out",
	stumped: "Stumped",
	hit_wicket: "Hit wicket"
};
function formatCredits(n) {
	return n.toFixed(1);
}
function formatOvers(legalBalls) {
	return `${Math.floor(legalBalls / 6)}.${legalBalls % 6}`;
}
function strikeRate(runs, balls) {
	if (balls <= 0) return 0;
	return runs / balls * 100;
}
function economy(runs, balls) {
	if (balls <= 0) return 0;
	return runs / balls * 6;
}
function currentRunRate(runs, legalBalls) {
	if (legalBalls <= 0) return 0;
	return runs / legalBalls * 6;
}
function requiredRunRate(runs, target, legalBalls, oversLimit) {
	const remaining = oversLimit * 6 - legalBalls;
	if (remaining <= 0) return 0;
	return (target - runs) / remaining * 6;
}
function formatRate(n) {
	if (!Number.isFinite(n)) return "—";
	return n.toFixed(2);
}
function playerById(players, id) {
	if (!id) return void 0;
	return players.find((p) => p.id === id);
}
function opposite(side) {
	return side === "A" ? "B" : "A";
}
function dismissalText(wicket, players, bowlerId) {
	const bowler = playerById(players, bowlerId)?.name ?? "bowler";
	const fielder = wicket.fielderId ? playerById(players, wicket.fielderId)?.name ?? "fielder" : void 0;
	switch (wicket.kind) {
		case "bowled": return `b ${bowler}`;
		case "lbw": return `lbw b ${bowler}`;
		case "hit_wicket": return `hit wicket b ${bowler}`;
		case "caught": return fielder ? `c ${fielder} b ${bowler}` : `c & b ${bowler}`;
		case "stumped": return fielder ? `st ${fielder} b ${bowler}` : `st b ${bowler}`;
		case "run_out": return fielder ? `run out (${fielder})` : "run out";
	}
}
function formatDateTime(iso) {
	const d = new Date(iso);
	if (Number.isNaN(d.getTime())) return iso;
	return new Intl.DateTimeFormat(void 0, {
		weekday: "short",
		day: "numeric",
		month: "short",
		hour: "numeric",
		minute: "2-digit"
	}).format(d);
}
function ballsLabel(d) {
	if (d.kind === "dead") return "•";
	if (d.wicket) return "W";
	if (d.kind === "wide") return d.extraRuns > 1 ? `wd+${d.extraRuns - 1}` : "wd";
	if (d.kind === "noball") return d.batRuns > 0 ? `nb+${d.batRuns}` : "nb";
	if (d.kind === "bye") return `b${d.extraRuns}`;
	if (d.kind === "legbye") return `lb${d.extraRuns}`;
	if (d.batRuns === 0) return ".";
	return String(d.batRuns);
}
function maxWickets(teamSize) {
	return Math.max(1, teamSize - 1);
}
//#endregion
export { currentRunRate as a, formatCredits as c, formatRate as d, maxWickets as f, strikeRate as g, requiredRunRate as h, ballsLabel as i, formatDateTime as l, playerById as m, DISMISSAL_LABEL as n, dismissalText as o, opposite as p, ROLE_NAME as r, economy as s, Button as t, formatOvers as u };
