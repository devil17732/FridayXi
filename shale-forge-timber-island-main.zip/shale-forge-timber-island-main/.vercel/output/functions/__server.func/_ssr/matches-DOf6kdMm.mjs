import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as Link, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { c as Plus, l as MapPin, m as ArrowRight } from "../_libs/lucide-react.mjs";
import { r as useCricketStore } from "./router-BmrXQEZs.mjs";
import { l as formatDateTime, t as Button, u as formatOvers } from "./format-BLq0qNgQ.mjs";
import { n as CardContent, t as Card } from "./card-2AIXe0_p.mjs";
import { i as projectMatch } from "./scoring-B28a5nGP.mjs";
import { n as Label, t as Input } from "./label-DFuEgEjq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/matches-DOf6kdMm.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function nextFridayEvening() {
	const d = /* @__PURE__ */ new Date();
	const day = d.getDay();
	const days = day === 5 ? 0 : (5 - day + 7) % 7;
	d.setDate(d.getDate() + days);
	d.setHours(18, 30, 0, 0);
	const pad = (n) => String(n).padStart(2, "0");
	return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
function MatchesPage() {
	const matches = useCricketStore((s) => s.matches);
	const createMatch = useCricketStore((s) => s.createMatch);
	const teamAName = useCricketStore((s) => s.teamAName);
	const teamBName = useCricketStore((s) => s.teamBName);
	const teamAIds = useCricketStore((s) => s.teamAIds);
	const teamBIds = useCricketStore((s) => s.teamBIds);
	const navigate = useNavigate();
	const [venue, setVenue] = (0, import_react.useState)("Club ground");
	const [startTime, setStartTime] = (0, import_react.useState)(nextFridayEvening);
	const [overs, setOvers] = (0, import_react.useState)(String(20));
	const views = (0, import_react.useMemo)(() => matches.map(projectMatch), [matches]);
	const canCreate = teamAIds.length >= 2 && teamBIds.length >= 2;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl tracking-tight",
				children: "Matches"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm text-muted",
				children: [
					teamAName,
					" vs ",
					teamBName,
					" — set the ground and start scoring."
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "space-y-4 p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5 sm:col-span-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "venue",
									children: "Venue"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "venue",
									value: venue,
									onChange: (e) => setVenue(e.target.value)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "when",
									children: "When"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "when",
									type: "datetime-local",
									value: startTime,
									onChange: (e) => setStartTime(e.target.value)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "overs",
									children: "Overs"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "overs",
									type: "number",
									min: 5,
									max: 50,
									value: overs,
									onChange: (e) => setOvers(e.target.value)
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						disabled: !canCreate,
						onClick: () => {
							const id = createMatch({
								venue,
								startTime: new Date(startTime).toISOString(),
								oversLimit: Math.min(50, Math.max(5, Number(overs) || 20))
							});
							navigate({
								to: "/matches/$matchId",
								params: { matchId: id }
							});
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Create match"]
					}),
					!canCreate ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: "Balance two sides first — each team needs at least two players."
					}) : null
				]
			}) }),
			views.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "No matches yet. Create this Friday’s fixture."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: views.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/matches/$matchId",
					params: { matchId: v.match.id },
					className: "flex items-center justify-between gap-3 rounded-xl border border-border bg-surface px-4 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-medium",
								children: [
									v.match.teamAName,
									" vs ",
									v.match.teamBName
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 flex flex-wrap items-center gap-x-2 text-xs text-muted",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3" }),
									v.match.venue,
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["· ", formatDateTime(v.match.startTime)] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										"· ",
										v.match.oversLimit,
										" ov"
									] })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-fg",
								children: v.result ? v.result : v.current ? `${v.current.runs}/${v.current.wickets} (${formatOvers(v.current.legalBalls)})` : "Toss pending"
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 shrink-0 text-faint" })]
				}) }, v.match.id))
			})
		]
	});
}
//#endregion
export { MatchesPage as component };
