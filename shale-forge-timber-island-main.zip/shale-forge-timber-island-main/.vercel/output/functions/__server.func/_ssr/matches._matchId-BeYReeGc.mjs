import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { h as ArrowLeft } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as uid, i as cn, n as Route, r as useCricketStore } from "./router-BmrXQEZs.mjs";
import { a as currentRunRate, d as formatRate, g as strikeRate, h as requiredRunRate, l as formatDateTime, m as playerById, n as DISMISSAL_LABEL, o as dismissalText, s as economy, t as Button, u as formatOvers } from "./format-BLq0qNgQ.mjs";
import { a as yetToBat, i as projectMatch, n as availableBowlers, r as buildDelivery, t as availableBatsmen } from "./scoring-B28a5nGP.mjs";
import { t as RoleBadge } from "./role-badge-WQkFGEF3.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, r as DialogDescription, t as Dialog } from "./dialog-Byvmn2bz.mjs";
import { i as Trigger, n as List, r as Root2, t as Content } from "../_libs/radix-ui__react-tabs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/matches._matchId-BeYReeGc.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CoinToss({ teamAName, teamBName, onComplete }) {
	const [caller, setCaller] = (0, import_react.useState)("A");
	const [call, setCall] = (0, import_react.useState)("heads");
	const [flipping, setFlipping] = (0, import_react.useState)(false);
	const [coin, setCoin] = (0, import_react.useState)(null);
	const [flips, setFlips] = (0, import_react.useState)(8);
	const [winner, setWinner] = (0, import_react.useState)(null);
	const face = coin ?? "heads";
	const rotate = coin === "tails" ? flips * 360 + 180 : flips * 360;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-md space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl tracking-tight",
				children: "Toss"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "Call it in the air. Winner chooses bat or field."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
						active: caller === "A",
						onClick: () => setCaller("A"),
						disabled: Boolean(coin) || flipping,
						label: teamAName,
						hint: "calls"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
						active: caller === "B",
						onClick: () => setCaller("B"),
						disabled: Boolean(coin) || flipping,
						label: teamBName,
						hint: "calls"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
						active: call === "heads",
						onClick: () => setCall("heads"),
						disabled: Boolean(coin) || flipping,
						label: "Heads"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
						active: call === "tails",
						onClick: () => setCall("tails"),
						disabled: Boolean(coin) || flipping,
						label: "Tails"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-center py-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "coin",
					style: { transform: `rotateY(${rotate}deg)` },
					"aria-hidden": true,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "coin-face",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-xl",
							children: "Heads"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "coin-face tails",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-xl",
							children: "Tails"
						})
					})]
				})
			}),
			!coin ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "w-full",
				size: "lg",
				disabled: flipping,
				onClick: () => {
					const next = Math.random() < .5 ? "heads" : "tails";
					setFlipping(true);
					setFlips((n) => n + 6 + Math.floor(Math.random() * 4));
					window.setTimeout(() => {
						setCoin(next);
						setWinner(next === call ? caller : caller === "A" ? "B" : "A");
						setFlipping(false);
					}, 1600);
				},
				children: flipping ? "In the air…" : "Flip coin"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-center text-sm text-muted",
					children: [
						face === "heads" ? "Heads" : "Tails",
						".",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-fg",
							children: [winner === "A" ? teamAName : teamBName, " won the toss."]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						onClick: () => winner && onComplete({
							winner,
							decision: "bat",
							coin: face
						}),
						children: "Bat"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						variant: "secondary",
						onClick: () => winner && onComplete({
							winner,
							decision: "field",
							coin: face
						}),
						children: "Field"
					})]
				})]
			})
		]
	});
}
function Choice({ active, onClick, label, hint, disabled }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		disabled,
		onClick,
		className: cn("min-h-14 rounded-xl border px-3 py-3 text-left transition-colors duration-150", active ? "border-accent bg-accent/10 text-fg" : "border-border bg-surface text-muted"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "block truncate text-sm font-medium",
			children: label
		}), hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs text-faint",
			children: hint
		}) : null]
	});
}
function LiveBoard({ view, inn }) {
	const battingName = inn.battingSide === "A" ? view.match.teamAName : view.match.teamBName;
	const crr = currentRunRate(inn.runs, inn.legalBalls);
	const rrr = inn.target != null ? requiredRunRate(inn.runs, inn.target, inn.legalBalls, view.match.oversLimit) : null;
	const striker = inn.batters.find((b) => b.playerId === inn.strikerId);
	const non = inn.batters.find((b) => b.playerId === inn.nonStrikerId);
	const bowler = inn.bowlers.find((b) => b.playerId === inn.bowlerId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 rounded-xl border border-border bg-surface p-4 sm:p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-[0.16em] text-muted",
						children: battingName
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 font-display text-4xl tabular-nums tracking-tight",
						children: [inn.runs, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-muted",
							children: ["/", inn.wickets]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted",
						children: [
							formatOvers(inn.legalBalls),
							" ov",
							inn.target != null ? ` · Target ${inn.target}` : ""
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-right text-xs text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["CRR ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums text-fg",
							children: formatRate(crr)
						})] }),
						rrr != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1",
							children: ["RRR ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums text-fg",
								children: formatRate(rrr)
							})]
						}) : null,
						inn.freeHit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 font-medium uppercase tracking-[0.14em] text-accent",
							children: "Free hit"
						}) : null
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BatterRow, {
					line: striker,
					nameFallback: playerById(inn.batting, inn.strikerId)?.name,
					onStrike: true
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BatterRow, {
					line: non,
					nameFallback: playerById(inn.batting, inn.nonStrikerId)?.name
				})]
			}),
			bowler ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					bowler.name,
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "tabular-nums text-fg",
						children: [
							formatOvers(bowler.balls),
							"–",
							bowler.maidens,
							"–",
							bowler.runs,
							"–",
							bowler.wickets
						]
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs uppercase tracking-[0.14em] text-muted",
				children: "This over"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 flex flex-wrap gap-1.5",
				children: inn.thisOver.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm text-faint",
					children: "Yet to start"
				}) : inn.thisOver.map((ball, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: cn("inline-flex min-w-8 items-center justify-center rounded-md px-1.5 py-1 text-xs tabular-nums", ball === "W" ? "bg-danger/20 text-danger" : ball === "4" || ball === "6" ? "bg-accent/20 text-accent" : "bg-surface-2 text-fg"),
					children: ball
				}, `${ball}-${i}`))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted",
				children: [
					"Partnership ",
					inn.partnership.runs,
					" (",
					inn.partnership.balls,
					")"
				]
			})
		]
	});
}
function BatterRow({ line, nameFallback, onStrike }) {
	const name = line?.name ?? nameFallback ?? "—";
	const sr = line ? strikeRate(line.runs, line.balls) : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between gap-3 rounded-lg bg-surface-2 px-3 py-2 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: cn("truncate", onStrike && "text-accent"),
			children: [name, onStrike ? " *" : ""]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "shrink-0 tabular-nums text-muted",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-fg",
					children: line?.runs ?? 0
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-faint",
					children: [
						" (",
						line?.balls ?? 0,
						")"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "ml-2 hidden sm:inline",
					children: formatRate(sr)
				})
			]
		})]
	});
}
function PlayerPick({ title, hint, players, selected, onToggle, max = 1, confirmLabel, onConfirm, disabledIds }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl tracking-tight",
				children: title
			}), hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: hint
			}) : null] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid gap-2 sm:grid-cols-2",
				children: players.map((p) => {
					const on = selected.includes(p.id);
					const locked = disabledIds?.has(p.id) ?? false;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						disabled: locked,
						onClick: () => onToggle(p.id),
						className: cn("flex w-full min-h-12 items-center justify-between gap-2 rounded-xl border px-3 py-3 text-left", on ? "border-accent bg-accent/10" : "border-border bg-surface", locked && "opacity-40"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "truncate text-sm font-medium",
							children: p.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoleBadge, { role: p.role })]
					}) }, p.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "w-full",
				size: "lg",
				disabled: selected.length !== max,
				onClick: onConfirm,
				children: confirmLabel
			})
		]
	});
}
var Tabs = Root2;
var TabsList = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, {
	ref,
	className: cn("inline-flex h-11 items-center gap-1 rounded-lg bg-surface-2 p-1 text-muted", className),
	...props
}));
TabsList.displayName = List.displayName;
var TabsTrigger = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trigger, {
	ref,
	className: cn("inline-flex h-9 items-center justify-center rounded-md px-3 text-sm font-medium transition-[background-color,color] duration-150 data-[state=active]:bg-surface data-[state=active]:text-fg", className),
	...props
}));
TabsTrigger.displayName = Trigger.displayName;
var TabsContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content, {
	ref,
	className: cn("mt-4", className),
	...props
}));
TabsContent.displayName = Content.displayName;
function Scorecard({ view }) {
	if (view.innings.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: "Scorecard opens after the toss."
	});
	const defaultTab = String(view.innings.length - 1);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
		defaultValue: defaultTab,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsList, {
			className: "w-full",
			children: view.innings.map((inn, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
				value: String(i),
				className: "flex-1",
				children: inn.battingSide === "A" ? view.match.teamAName : view.match.teamBName
			}, inn.index))
		}), view.innings.map((inn, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
			value: String(i),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InningsCard, { inn })
		}, inn.index))]
	});
}
function InningsCard({ inn }) {
	const waiting = yetToBat(inn);
	const allPlayers = [...inn.batting, ...inn.bowling];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "font-display text-2xl tabular-nums",
				children: [
					inn.runs,
					"/",
					inn.wickets,
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-base text-muted",
						children: [
							"(",
							formatOvers(inn.legalBalls),
							" ov)"
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[28rem] text-left text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "text-xs uppercase tracking-wide text-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 font-medium",
								children: "Batter"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 font-medium",
								children: " "
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 text-right font-medium",
								children: "R"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 text-right font-medium",
								children: "B"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 text-right font-medium",
								children: "4"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 text-right font-medium",
								children: "6"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 text-right font-medium",
								children: "SR"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: inn.batters.map((b) => {
						const wicketBall = inn.deliveries.find((d) => d.wicket?.batsmanId === b.playerId);
						const how = wicketBall?.wicket && wicketBall ? dismissalText(wicketBall.wicket, allPlayers, wicketBall.bowlerId) : "not out";
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-t border-border",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2 pr-2 font-medium",
									children: b.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2 text-xs text-muted",
									children: how
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2 text-right tabular-nums",
									children: b.runs
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2 text-right tabular-nums text-muted",
									children: b.balls
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2 text-right tabular-nums text-muted",
									children: b.fours
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2 text-right tabular-nums text-muted",
									children: b.sixes
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2 text-right tabular-nums text-muted",
									children: formatRate(strikeRate(b.runs, b.balls))
								})
							]
						}, b.playerId);
					}) })]
				})
			}),
			waiting.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted",
				children: ["Yet to bat: ", waiting.map((p) => p.name).join(", ")]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted",
				children: [
					"Extras ",
					inn.extras.total,
					" (wd ",
					inn.extras.wides,
					", nb ",
					inn.extras.noballs,
					", b",
					" ",
					inn.extras.byes,
					", lb ",
					inn.extras.legbyes,
					")"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[22rem] text-left text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "text-xs uppercase tracking-wide text-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 font-medium",
								children: "Bowler"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 text-right font-medium",
								children: "O"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 text-right font-medium",
								children: "M"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 text-right font-medium",
								children: "R"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 text-right font-medium",
								children: "W"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 text-right font-medium",
								children: "Econ"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: inn.bowlers.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t border-border",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 font-medium",
								children: b.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 text-right tabular-nums",
								children: formatOvers(b.balls)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 text-right tabular-nums",
								children: b.maidens
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 text-right tabular-nums",
								children: b.runs
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 text-right tabular-nums",
								children: b.wickets
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 text-right tabular-nums text-muted",
								children: formatRate(economy(b.runs, b.balls))
							})
						]
					}, b.playerId)) })]
				})
			})
		]
	});
}
function ScoringPad({ inn, onBall, onUndo, canUndo, onEndInnings }) {
	const [extra, setExtra] = (0, import_react.useState)(null);
	const [wicketOpen, setWicketOpen] = (0, import_react.useState)(false);
	const [kind, setKind] = (0, import_react.useState)("bowled");
	const [outId, setOutId] = (0, import_react.useState)(inn.strikerId ?? "");
	const [fielderId, setFielderId] = (0, import_react.useState)("");
	const needsFielder = kind === "caught" || kind === "run_out" || kind === "stumped";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			extra ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExtraStrip, {
				kind: extra,
				onCancel: () => setExtra(null),
				onPick: (batRuns, extraRuns) => {
					onBall({
						kind: extra,
						batRuns,
						extraRuns
					});
					setExtra(null);
				}
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-3 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PadBtn, {
						onClick: () => onBall({
							kind: "normal",
							batRuns: 0,
							extraRuns: 0
						}),
						children: "0"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PadBtn, {
						onClick: () => onBall({
							kind: "normal",
							batRuns: 1,
							extraRuns: 0
						}),
						children: "1"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PadBtn, {
						onClick: () => onBall({
							kind: "normal",
							batRuns: 2,
							extraRuns: 0
						}),
						children: "2"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PadBtn, {
						onClick: () => onBall({
							kind: "normal",
							batRuns: 3,
							extraRuns: 0
						}),
						children: "3"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PadBtn, {
						className: "bg-accent/15 text-fg",
						onClick: () => onBall({
							kind: "normal",
							batRuns: 4,
							extraRuns: 0
						}),
						children: "4"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PadBtn, {
						className: "bg-accent/25 text-fg",
						onClick: () => onBall({
							kind: "normal",
							batRuns: 6,
							extraRuns: 0
						}),
						children: "6"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PadBtn, {
						className: "bg-danger/20 text-danger",
						onClick: () => {
							setOutId(inn.strikerId ?? "");
							setKind("bowled");
							setFielderId("");
							setWicketOpen(true);
						},
						children: "Wicket"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PadBtn, {
						onClick: () => setExtra("wide"),
						children: "Wide"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PadBtn, {
						onClick: () => setExtra("noball"),
						children: "No ball"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PadBtn, {
						onClick: () => setExtra("bye"),
						children: "Bye"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PadBtn, {
						onClick: () => setExtra("legbye"),
						children: "Leg bye"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PadBtn, {
						onClick: () => onBall({
							kind: "dead",
							batRuns: 0,
							extraRuns: 0
						}),
						children: "Dead"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "flex-1",
					variant: "outline",
					disabled: !canUndo,
					onClick: onUndo,
					children: "Undo ball"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					onClick: onEndInnings,
					children: "End innings"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: wicketOpen,
				onOpenChange: setWicketOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Wicket" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "How they got out, and who is walking." })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-2",
						children: Object.keys(DISMISSAL_LABEL).map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setKind(k),
							className: cn("min-h-11 rounded-lg border px-3 text-sm", kind === k ? "border-accent bg-accent/10" : "border-border bg-surface-2"),
							children: DISMISSAL_LABEL[k]
						}, k))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: "Batter out"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [inn.strikerId, inn.nonStrikerId].filter(Boolean).map((id) => {
							const p = inn.batting.find((x) => x.id === id);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setOutId(id),
								className: cn("min-h-11 rounded-lg border px-3 text-sm", outId === id ? "border-accent bg-accent/10" : "border-border bg-surface-2"),
								children: p?.name ?? "Batter"
							}, id);
						})
					}),
					needsFielder ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: "Fielder"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid max-h-40 grid-cols-2 gap-2 overflow-y-auto",
						children: inn.bowling.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setFielderId(p.id),
							className: cn("min-h-11 rounded-lg border px-3 text-left text-sm", fielderId === p.id ? "border-accent bg-accent/10" : "border-border bg-surface-2"),
							children: p.name
						}, p.id))
					})] }) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "w-full",
						disabled: !outId || needsFielder && !fielderId,
						onClick: () => {
							onBall({
								kind: "wicket",
								batRuns: 0,
								extraRuns: 0,
								wicket: {
									kind,
									batsmanId: outId,
									fielderId: needsFielder ? fielderId : void 0
								}
							});
							setWicketOpen(false);
						},
						children: "Record wicket"
					})
				] })
			})
		]
	});
}
function ExtraStrip({ kind, onCancel, onPick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2 rounded-xl border border-border bg-surface-2 p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium",
				children: kind === "wide" ? "Wide — extra runs run?" : kind === "noball" ? "No ball — runs off the bat" : kind === "bye" ? "Byes" : "Leg byes"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "text-xs text-muted",
				onClick: onCancel,
				children: "Cancel"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-3 gap-2",
			children: (kind === "noball" ? [
				0,
				1,
				2,
				3,
				4,
				6
			] : kind === "wide" ? [
				0,
				1,
				2,
				3,
				4
			] : [
				1,
				2,
				3,
				4
			]).map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PadBtn, {
				onClick: () => {
					if (kind === "noball") onPick(n, 1);
					else if (kind === "wide") onPick(0, 1 + n);
					else onPick(0, n);
				},
				children: kind === "wide" ? n === 0 ? "Wide" : `+${n}` : n
			}, n))
		})]
	});
}
function PadBtn({ children, onClick, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: cn("flex h-14 items-center justify-center rounded-xl border border-border bg-surface text-base font-semibold tabular-nums transition-transform duration-150 active:scale-[0.96]", className),
		children
	});
}
function MatchPage() {
	const { matchId } = Route.useParams();
	const match = useCricketStore((s) => s.matches.find((m) => m.id === matchId));
	const pushEvent = useCricketStore((s) => s.pushEvent);
	const undoEvent = useCricketStore((s) => s.undoEvent);
	const deleteMatch = useCricketStore((s) => s.deleteMatch);
	const view = (0, import_react.useMemo)(() => match ? projectMatch(match) : null, [match]);
	const [picked, setPicked] = (0, import_react.useState)([]);
	const [tab, setTab] = (0, import_react.useState)("score");
	if (!match || !view) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: "That match is not on the book."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			asChild: true,
			variant: "secondary",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/matches",
				children: "Back to matches"
			})
		})]
	});
	const inn = view.current;
	const inningsIndex = inn?.index ?? 0;
	const togglePick = (id, max) => {
		setPicked((cur) => {
			if (cur.includes(id)) return cur.filter((x) => x !== id);
			if (cur.length >= max) return [...cur.slice(1), id];
			return [...cur, id];
		});
	};
	const recordBall = (payload) => {
		if (!inn || !inn.strikerId || !inn.nonStrikerId || !inn.bowlerId) return;
		if (inn.freeHit && payload.wicket && payload.wicket.kind !== "run_out") {
			toast.error("Free hit — only a run out can fall.");
			return;
		}
		const delivery = buildDelivery({
			id: uid(),
			kind: payload.kind,
			batRuns: payload.batRuns,
			extraRuns: payload.extraRuns,
			strikerId: inn.strikerId,
			nonStrikerId: inn.nonStrikerId,
			bowlerId: inn.bowlerId,
			freeHit: inn.freeHit,
			wicket: payload.wicket
		});
		pushEvent(match.id, {
			id: uid(),
			type: "delivery",
			innings: inningsIndex,
			delivery
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/matches",
						className: "inline-flex items-center gap-1 text-xs text-muted hover:text-fg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-3.5" }), "Matches"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "mt-2 font-display text-2xl tracking-tight sm:text-3xl",
						children: [
							match.teamAName,
							" vs ",
							match.teamBName
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted",
						children: [
							match.venue,
							" · ",
							formatDateTime(match.startTime),
							" · ",
							match.oversLimit,
							" ov"
						]
					})
				] }), view.phase !== "complete" && match.events.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "sm",
					onClick: () => undoEvent(match.id),
					children: "Undo"
				}) : null]
			}),
			view.toss ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					view.toss.winner === "A" ? match.teamAName : match.teamBName,
					" won the toss and chose to ",
					view.toss.decision,
					"."
				]
			}) : null,
			view.result ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl border border-border bg-surface px-4 py-3 font-display text-xl",
				children: view.result
			}) : null,
			view.phase !== "scheduled" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: tab === "score" ? "default" : "outline",
					onClick: () => setTab("score"),
					children: "Scoring"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: tab === "card" ? "default" : "outline",
					onClick: () => setTab("card"),
					children: "Scorecard"
				})]
			}) : null,
			tab === "card" && view.phase !== "scheduled" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scorecard, { view }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				inn && view.phase !== "scheduled" && view.phase !== "openers" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveBoard, {
					view,
					inn
				}) : null,
				view.phase === "scheduled" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CoinToss, {
					teamAName: match.teamAName,
					teamBName: match.teamBName,
					onComplete: (result) => {
						pushEvent(match.id, {
							id: uid(),
							type: "toss",
							...result
						});
						setPicked([]);
					}
				}) : null,
				view.phase === "openers" && inn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerPick, {
					title: inn.index === 1 ? `Chase ${inn.target ?? ""}` : "Openers",
					hint: inn.index === 1 ? `Need ${inn.target} to win. Pick the striker first, then the non-striker.` : "Pick the striker first, then the non-striker.",
					players: availableBatsmen(inn).length ? availableBatsmen(inn) : inn.batting,
					selected: picked,
					max: 2,
					confirmLabel: "Confirm openers",
					onToggle: (id) => togglePick(id, 2),
					onConfirm: () => {
						if (picked.length !== 2) return;
						pushEvent(match.id, {
							id: uid(),
							type: "openers",
							innings: inningsIndex,
							strikerId: picked[0],
							nonStrikerId: picked[1]
						});
						setPicked([]);
					}
				}) : null,
				view.phase === "new_batsman" && inn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerPick, {
					title: "New batter",
					hint: "Who is walking in?",
					players: availableBatsmen(inn),
					selected: picked,
					max: 1,
					confirmLabel: "Send in",
					onToggle: (id) => togglePick(id, 1),
					onConfirm: () => {
						if (!picked[0]) return;
						pushEvent(match.id, {
							id: uid(),
							type: "new_batsman",
							innings: inningsIndex,
							batsmanId: picked[0]
						});
						setPicked([]);
					}
				}) : null,
				(view.phase === "over_change" || view.phase === "live" && inn && !inn.bowlerId) && inn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerPick, {
					title: inn.legalBalls === 0 ? "Opening bowler" : "Next bowler",
					hint: "A bowler cannot bowl consecutive overs.",
					players: availableBowlers(inn),
					selected: picked,
					max: 1,
					confirmLabel: "Confirm bowler",
					disabledIds: inn.lastBowlerId ? /* @__PURE__ */ new Set([inn.lastBowlerId]) : void 0,
					onToggle: (id) => togglePick(id, 1),
					onConfirm: () => {
						if (!picked[0]) return;
						pushEvent(match.id, {
							id: uid(),
							type: "bowler",
							innings: inningsIndex,
							bowlerId: picked[0]
						});
						setPicked([]);
					}
				}) : null,
				view.phase === "innings_break" && inn ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3 rounded-xl border border-border bg-surface p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-xl",
							children: "Innings break"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [
								inn.runs,
								"/",
								inn.wickets,
								" on the board. Open the chase when the field is set."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: "The second innings opens automatically — pick the new openers below once you continue."
						})
					]
				}) : null,
				view.phase === "live" && inn && inn.bowlerId && inn.strikerId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScoringPad, {
					inn,
					onBall: recordBall,
					onUndo: () => undoEvent(match.id),
					canUndo: match.events.length > 0,
					onEndInnings: () => {
						pushEvent(match.id, {
							id: uid(),
							type: "end_innings",
							innings: inningsIndex,
							reason: "manual"
						});
					}
				}) : null,
				view.phase === "complete" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scorecard, { view }) : null
			] }),
			view.phase === "complete" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "sm",
				onClick: () => deleteMatch(match.id),
				children: "Remove from book"
			}) : null
		]
	});
}
//#endregion
export { MatchPage as component };
