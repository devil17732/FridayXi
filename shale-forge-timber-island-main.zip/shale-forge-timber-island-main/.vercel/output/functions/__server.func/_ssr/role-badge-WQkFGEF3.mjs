import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { i as cn } from "./router-BmrXQEZs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/role-badge-WQkFGEF3.js
var import_jsx_runtime = require_jsx_runtime();
var badgeVariants = cva("inline-flex items-center rounded-full border px-2 py-0.5 text-xs font-medium tracking-wide uppercase", {
	variants: { variant: {
		default: "border-transparent bg-surface-2 text-muted",
		accent: "border-transparent bg-accent/15 text-accent",
		outline: "border-border text-muted",
		danger: "border-transparent bg-danger/15 text-danger"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
function RoleBadge({ role }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		variant: role === "AR" ? "accent" : "default",
		children: role
	});
}
//#endregion
export { RoleBadge as t };
