import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as createRootRoute, b as useRouter, d as useRouterState, g as createFileRoute, h as lazyRouteComponent, l as Scripts, m as Outlet, p as createRouter, u as HeadContent, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as Swords, n as Trophy, r as TriangleAlert, s as Shirt, u as LayoutGrid } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-BmrXQEZs.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
function roleLimits(teamSize) {
	if (teamSize >= 11) return {
		WK: {
			min: 1,
			max: 4
		},
		BAT: {
			min: 3,
			max: 6
		},
		AR: {
			min: 1,
			max: 4
		},
		BOWL: {
			min: 3,
			max: 6
		}
	};
	if (teamSize >= 8) return {
		WK: {
			min: 1,
			max: 2
		},
		BAT: {
			min: 2,
			max: 5
		},
		AR: {
			min: 1,
			max: 3
		},
		BOWL: {
			min: 2,
			max: 5
		}
	};
	return {
		WK: {
			min: 0,
			max: 2
		},
		BAT: {
			min: 1,
			max: 4
		},
		AR: {
			min: 0,
			max: 3
		},
		BOWL: {
			min: 1,
			max: 4
		}
	};
}
function roleCounts(players) {
	const counts = {
		WK: 0,
		BAT: 0,
		AR: 0,
		BOWL: 0
	};
	for (const p of players) counts[p.role] += 1;
	return counts;
}
function creditSum(players) {
	return players.reduce((s, p) => s + p.credits, 0);
}
function roleWarnings(players, teamSize) {
	const limits = roleLimits(teamSize);
	const counts = roleCounts(players);
	const warnings = [];
	Object.keys(limits).forEach((role) => {
		const { min, max } = limits[role];
		const n = counts[role];
		if (n < min) warnings.push(`Need at least ${min} ${role}`);
		if (n > max) warnings.push(`At most ${max} ${role}`);
	});
	if (players.length > teamSize) warnings.push(`Over XI (${players.length}/${teamSize})`);
	return warnings;
}
function rolePenalty(players, teamSize) {
	const limits = roleLimits(teamSize);
	const counts = roleCounts(players);
	let p = 0;
	Object.keys(limits).forEach((role) => {
		const { min, max } = limits[role];
		const n = counts[role];
		if (n < min) p += (min - n) * 6;
		if (n > max) p += (n - max) * 4;
		if (n === 0 && min > 0) p += 8;
	});
	return p;
}
function scoreSplit(a, b, teamSize, budget) {
	const diff = Math.abs(creditSum(a) - creditSum(b));
	const over = Math.max(0, creditSum(a) - budget) + Math.max(0, creditSum(b) - budget);
	const roles = rolePenalty(a, teamSize) + rolePenalty(b, teamSize);
	const size = Math.abs(a.length - teamSize) * 12 + Math.abs(b.length - teamSize) * 12;
	return diff + over * 3 + roles * 2 + size;
}
function assignSnake(players, size) {
	const sorted = [...players].sort((x, y) => y.credits - x.credits || x.name.localeCompare(y.name));
	const a = [];
	const b = [];
	for (const p of sorted) {
		if (a.length >= size) {
			b.push(p);
			continue;
		}
		if (b.length >= size) {
			a.push(p);
			continue;
		}
		if (a.length !== b.length) {
			(a.length < b.length ? a : b).push(p);
			continue;
		}
		(creditSum(a) <= creditSum(b) ? a : b).push(p);
	}
	return {
		a,
		b
	};
}
function optimize(a, b, teamSize, budget) {
	let best = scoreSplit(a, b, teamSize, budget);
	let improved = true;
	let rounds = 0;
	while (improved && rounds < 8) {
		improved = false;
		rounds += 1;
		for (let i = 0; i < a.length; i += 1) for (let j = 0; j < b.length; j += 1) {
			const tmp = a[i];
			a[i] = b[j];
			b[j] = tmp;
			const s = scoreSplit(a, b, teamSize, budget);
			if (s + 1e-9 < best) {
				best = s;
				improved = true;
			} else {
				const revert = a[i];
				a[i] = b[j];
				b[j] = revert;
			}
		}
	}
}
function autoBalance(players, teamSize, budget) {
	const size = Math.min(teamSize, Math.floor(players.length / 2));
	if (size < 1) return {
		a: [],
		b: [],
		bench: [...players],
		size: 0
	};
	const selected = [...players].sort((x, y) => y.credits - x.credits || x.name.localeCompare(y.name)).slice(0, size * 2);
	const selectedIds = new Set(selected.map((p) => p.id));
	const bench = players.filter((p) => !selectedIds.has(p.id));
	const { a, b } = assignSnake(selected, size);
	optimize(a, b, size, budget);
	a.sort((x, y) => y.credits - x.credits);
	b.sort((x, y) => y.credits - x.credits);
	return {
		a,
		b,
		bench,
		size
	};
}
var SEED_PLAYERS = [
	{
		id: "p01",
		name: "Rohan Mehta",
		role: "WK",
		credits: 9
	},
	{
		id: "p02",
		name: "Kabir Shah",
		role: "WK",
		credits: 8
	},
	{
		id: "p03",
		name: "Dev Patel",
		role: "WK",
		credits: 7
	},
	{
		id: "p04",
		name: "Arjun Rao",
		role: "BAT",
		credits: 10.5
	},
	{
		id: "p05",
		name: "Vikram Singh",
		role: "BAT",
		credits: 10
	},
	{
		id: "p06",
		name: "Neil Kapoor",
		role: "BAT",
		credits: 9
	},
	{
		id: "p07",
		name: "Sameer Joshi",
		role: "BAT",
		credits: 8.5
	},
	{
		id: "p08",
		name: "Farhan Ali",
		role: "BAT",
		credits: 8
	},
	{
		id: "p09",
		name: "Ishaan Verma",
		role: "BAT",
		credits: 7.5
	},
	{
		id: "p10",
		name: "Mohit Nair",
		role: "BAT",
		credits: 7
	},
	{
		id: "p11",
		name: "Yash Bhatia",
		role: "BAT",
		credits: 6.5
	},
	{
		id: "p12",
		name: "Karan Malhotra",
		role: "AR",
		credits: 9.5
	},
	{
		id: "p13",
		name: "Aditya Reddy",
		role: "AR",
		credits: 8.5
	},
	{
		id: "p14",
		name: "Rehan Khan",
		role: "AR",
		credits: 8
	},
	{
		id: "p15",
		name: "Nikhil Desai",
		role: "AR",
		credits: 7
	},
	{
		id: "p16",
		name: "Varun Iyer",
		role: "AR",
		credits: 6.5
	},
	{
		id: "p17",
		name: "Pranav Iyer",
		role: "BOWL",
		credits: 9
	},
	{
		id: "p18",
		name: "Sohail Ahmed",
		role: "BOWL",
		credits: 8.5
	},
	{
		id: "p19",
		name: "Rajat Gupta",
		role: "BOWL",
		credits: 8
	},
	{
		id: "p20",
		name: "Ankit Sharma",
		role: "BOWL",
		credits: 7.5
	},
	{
		id: "p21",
		name: "Harsh Vora",
		role: "BOWL",
		credits: 7
	},
	{
		id: "p22",
		name: "Tushar Menon",
		role: "BOWL",
		credits: 6.5
	},
	{
		id: "p23",
		name: "Aman Gill",
		role: "BOWL",
		credits: 6
	},
	{
		id: "p24",
		name: "Piyush Jain",
		role: "BOWL",
		credits: 5.5
	}
];
var DEFAULT_TEAM_A = "Pavilion";
var DEFAULT_TEAM_B = "Nursery";
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function uid() {
	if (typeof crypto !== "undefined" && crypto.randomUUID) return crypto.randomUUID();
	return `id_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}
function snapshotPlayers(ids, players) {
	return ids.map((id) => players.find((p) => p.id === id)).filter((p) => Boolean(p)).map((p) => ({
		id: p.id,
		name: p.name,
		role: p.role,
		credits: p.credits
	}));
}
function initialBalance() {
	const result = autoBalance(SEED_PLAYERS, 11, 100);
	return {
		teamAIds: result.a.map((p) => p.id),
		teamBIds: result.b.map((p) => p.id)
	};
}
var seeded = initialBalance();
var useCricketStore = create()(persist((set, get) => ({
	players: SEED_PLAYERS,
	selectedIds: SEED_PLAYERS.map((p) => p.id),
	teamAIds: seeded.teamAIds,
	teamBIds: seeded.teamBIds,
	teamAName: DEFAULT_TEAM_A,
	teamBName: DEFAULT_TEAM_B,
	teamSize: 11,
	budget: 100,
	matches: [],
	addPlayer: (input) => {
		const player = {
			id: uid(),
			...input
		};
		set((s) => ({
			players: [...s.players, player],
			selectedIds: [...s.selectedIds, player.id]
		}));
	},
	updatePlayer: (id, patch) => {
		set((s) => ({ players: s.players.map((p) => p.id === id ? {
			...p,
			...patch
		} : p) }));
	},
	removePlayer: (id) => {
		set((s) => ({
			players: s.players.filter((p) => p.id !== id),
			selectedIds: s.selectedIds.filter((x) => x !== id),
			teamAIds: s.teamAIds.filter((x) => x !== id),
			teamBIds: s.teamBIds.filter((x) => x !== id)
		}));
	},
	toggleSelected: (id) => {
		set((s) => {
			return { selectedIds: s.selectedIds.includes(id) ? s.selectedIds.filter((x) => x !== id) : [...s.selectedIds, id] };
		});
	},
	selectAllPlaying: () => {
		set((s) => ({ selectedIds: s.players.map((p) => p.id) }));
	},
	setTeamName: (side, name) => {
		set(side === "A" ? { teamAName: name } : { teamBName: name });
	},
	setTeamSize: (n) => set({ teamSize: n }),
	setBudget: (n) => set({ budget: n }),
	balanceTeams: () => {
		const s = get();
		const result = autoBalance(s.players.filter((p) => s.selectedIds.includes(p.id)), s.teamSize, s.budget);
		set({
			teamAIds: result.a.map((p) => p.id),
			teamBIds: result.b.map((p) => p.id)
		});
	},
	movePlayer: (id, to) => {
		set((s) => {
			const teamAIds = s.teamAIds.filter((x) => x !== id);
			const teamBIds = s.teamBIds.filter((x) => x !== id);
			if (to === "A") teamAIds.push(id);
			if (to === "B") teamBIds.push(id);
			return {
				teamAIds,
				teamBIds,
				selectedIds: s.selectedIds.includes(id) ? s.selectedIds : [...s.selectedIds, id]
			};
		});
	},
	restoreDemoSquad: () => {
		const next = autoBalance(SEED_PLAYERS, 11, 100);
		set({
			players: SEED_PLAYERS,
			selectedIds: SEED_PLAYERS.map((p) => p.id),
			teamAIds: next.a.map((p) => p.id),
			teamBIds: next.b.map((p) => p.id),
			teamAName: DEFAULT_TEAM_A,
			teamBName: DEFAULT_TEAM_B,
			teamSize: 11,
			budget: 100
		});
	},
	createMatch: ({ venue, startTime, oversLimit }) => {
		const s = get();
		const teamA = snapshotPlayers(s.teamAIds, s.players);
		const teamB = snapshotPlayers(s.teamBIds, s.players);
		const match = {
			id: uid(),
			createdAt: (/* @__PURE__ */ new Date()).toISOString(),
			venue: venue.trim() || "Local ground",
			startTime,
			oversLimit,
			teamAName: s.teamAName.trim() || "Pavilion",
			teamBName: s.teamBName.trim() || "Nursery",
			teamA,
			teamB,
			captainAId: teamA[0]?.id ?? "",
			captainBId: teamB[0]?.id ?? "",
			events: []
		};
		set({ matches: [match, ...s.matches] });
		return match.id;
	},
	deleteMatch: (id) => {
		set((s) => ({ matches: s.matches.filter((m) => m.id !== id) }));
	},
	pushEvent: (matchId, event) => {
		set((s) => ({ matches: s.matches.map((m) => m.id === matchId ? {
			...m,
			events: [...m.events, event]
		} : m) }));
	},
	undoEvent: (matchId) => {
		set((s) => ({ matches: s.matches.map((m) => m.id === matchId ? {
			...m,
			events: m.events.slice(0, -1)
		} : m) }));
	}
}), {
	name: "friday-xi-v1",
	storage: createJSONStorage(() => {
		if (typeof window === "undefined") return {
			getItem: () => null,
			setItem: () => {},
			removeItem: () => {}
		};
		return localStorage;
	}),
	skipHydration: true,
	partialize: (s) => ({
		players: s.players,
		selectedIds: s.selectedIds,
		teamAIds: s.teamAIds,
		teamBIds: s.teamBIds,
		teamAName: s.teamAName,
		teamBName: s.teamBName,
		teamSize: s.teamSize,
		budget: s.budget,
		matches: s.matches
	})
}));
function useHydrated() {
	const [ok, setOk] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const persist = useCricketStore.persist;
		const finish = () => setOk(true);
		const unsub = persist.onFinishHydration(finish);
		persist.rehydrate();
		if (persist.hasHydrated()) finish();
		return unsub;
	}, []);
	return ok;
}
var NAV = [
	{
		to: "/",
		label: "Home",
		icon: LayoutGrid
	},
	{
		to: "/squad",
		label: "Squad",
		icon: Shirt
	},
	{
		to: "/teams",
		label: "Sides",
		icon: Swords
	},
	{
		to: "/matches",
		label: "Matches",
		icon: Trophy
	}
];
function AppShell({ children }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex min-h-dvh max-w-5xl flex-col bg-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-30 flex items-center justify-between gap-3 border-b border-border bg-bg/90 px-4 py-3 backdrop-blur-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "flex items-baseline gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-xl font-medium tracking-tight text-fg",
						children: "Friday XI"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "hidden text-xs text-muted sm:inline",
						children: "Balance. Toss. Score."
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "hidden items-center gap-1 sm:flex",
					children: NAV.map((item) => {
						const active = item.to === "/" ? pathname === "/" : pathname === item.to || pathname.startsWith(`${item.to}/`);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: item.to,
							className: cn("rounded-lg px-3 py-2 text-sm transition-colors duration-150", active ? "bg-surface-2 text-fg" : "text-muted hover:text-fg"),
							children: item.label
						}, item.to);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "flex-1 px-4 pb-24 pt-6 sm:pb-10",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-30 border-t border-border bg-bg/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-sm sm:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid grid-cols-4",
					children: NAV.map((item) => {
						const Icon = item.icon;
						const active = item.to === "/" ? pathname === "/" : pathname === item.to || pathname.startsWith(`${item.to}/`);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: item.to,
							className: cn("flex min-h-14 flex-col items-center justify-center gap-1 text-xs font-medium", active ? "text-fg" : "text-muted"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "size-5",
								strokeWidth: 1.6
							}), item.label]
						}) }, item.to);
					})
				})
			})
		]
	});
}
function Skeleton({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("animate-pulse rounded-lg bg-surface-2", className),
		...props
	});
}
function HydrateGate({ children }) {
	if (!useHydrated()) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-48" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-28 w-full rounded-xl" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-28 w-full rounded-xl" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-40 w-full rounded-xl" })
		]
	}) });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children });
}
function Toaster$1() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
		theme: "dark",
		position: "top-center",
		toastOptions: { classNames: {
			toast: "bg-surface-2 text-fg border border-border shadow-none font-sans",
			title: "text-fg",
			description: "text-muted"
		} }
	});
}
var styles_default = "/assets/styles-DjerQcfF.css";
var APP_NAME = "Friday XI";
var Route$5 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "Balance Friday cricket sides, toss, and score every ball."
			},
			{
				name: "theme-color",
				content: "#0b0d0c"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			className: "bg-bg text-fg font-sans",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AuthProvider, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HydrateGate, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster$1, {})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
			]
		})]
	})
});
var $$splitComponentImporter$4 = () => import("./routes-BeSoxn6Q.mjs");
var Route$4 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./matches-DOf6kdMm.mjs");
var Route$3 = createFileRoute("/matches")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./squad-C0J463wy.mjs");
var Route$2 = createFileRoute("/squad")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./teams-DW8DGPHO.mjs");
var Route$1 = createFileRoute("/teams")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./matches._matchId-BeYReeGc.mjs");
var Route = createFileRoute("/matches/$matchId")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var IndexRoute = Route$4.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$5
});
var MatchesRoute = Route$3.update({
	id: "/matches",
	path: "/matches",
	getParentRoute: () => Route$5
});
var SquadRoute = Route$2.update({
	id: "/squad",
	path: "/squad",
	getParentRoute: () => Route$5
});
var TeamsRoute = Route$1.update({
	id: "/teams",
	path: "/teams",
	getParentRoute: () => Route$5
});
var MatchesRouteChildren = { MatchesMatchIdRoute: Route.update({
	id: "/$matchId",
	path: "/$matchId",
	getParentRoute: () => MatchesRoute
}) };
var rootRouteChildren = {
	IndexRoute,
	MatchesRoute: MatchesRoute._addFileChildren(MatchesRouteChildren),
	SquadRoute,
	TeamsRoute
};
var routeTree = Route$5._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { uid as a, roleLimits as c, cn as i, roleWarnings as l, Route as n, creditSum as o, useCricketStore as r, roleCounts as s, router_exports as t };
