import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as Swords, d as Coins, m as ArrowRight, s as Shirt } from "../_libs/lucide-react.mjs";
import { o as creditSum, r as useCricketStore } from "./router-BmrXQEZs.mjs";
import { l as formatDateTime, t as Button, u as formatOvers } from "./format-BLq0qNgQ.mjs";
import { n as CardContent, t as Card } from "./card-2AIXe0_p.mjs";
import { i as projectMatch } from "./scoring-B28a5nGP.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BeSoxn6Q.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const players = useCricketStore((s) => s.players);
	const teamAIds = useCricketStore((s) => s.teamAIds);
	const teamBIds = useCricketStore((s) => s.teamBIds);
	const teamAName = useCricketStore((s) => s.teamAName);
	const teamBName = useCricketStore((s) => s.teamBName);
	const matches = useCricketStore((s) => s.matches);
	const budget = useCricketStore((s) => s.budget);
	const teamA = players.filter((p) => teamAIds.includes(p.id));
	const teamB = players.filter((p) => teamBIds.includes(p.id));
	const live = matches.map(projectMatch).find((v) => v.phase !== "complete" && v.phase !== "scheduled");
	const next = matches.map((m) => ({
		m,
		v: projectMatch(m)
	})).find((x) => x.v.phase === "scheduled");
	const completed = matches.map(projectMatch).filter((v) => v.phase === "complete");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "stumps rise-in rounded-xl border border-border bg-surface px-5 py-8 sm:px-8 sm:py-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-[0.18em] text-accent",
						children: "Weekly cricket"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-3 max-w-lg font-display text-4xl font-medium leading-tight tracking-tight text-fg sm:text-5xl",
						children: "Fair sides. A proper toss. Every ball in the book."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-md text-sm leading-relaxed text-muted",
						children: "Price the squad like Dream11, split two XIs on a credit cap, then score the Friday game over by over."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 flex flex-wrap gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/teams",
								children: ["Balance sides", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: "secondary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/matches",
								children: "Open matches"
							})
						})]
					})
				]
			}),
			live ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/matches/$matchId",
				params: { matchId: live.match.id },
				className: "block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					className: "rise-in-2 overflow-hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-[0.16em] text-accent",
								children: "Live"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 font-display text-2xl tracking-tight",
								children: [
									live.match.teamAName,
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted",
										children: "vs"
									}),
									" ",
									live.match.teamBName
								]
							}),
							live.current ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-3 font-display text-3xl tabular-nums",
								children: [
									live.current.runs,
									"/",
									live.current.wickets,
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-lg text-muted",
										children: [
											"(",
											formatOvers(live.current.legalBalls),
											")"
										]
									})
								]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm text-muted",
								children: "Toss and openers next."
							})
						]
					})
				})
			}) : next ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/matches/$matchId",
				params: { matchId: next.m.id },
				className: "block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					className: "rise-in-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-[0.16em] text-muted",
								children: "Next up"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 font-display text-2xl tracking-tight",
								children: [
									next.m.teamAName,
									" vs ",
									next.m.teamBName
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 text-sm text-muted",
								children: [
									formatDateTime(next.m.startTime),
									" · ",
									next.m.venue
								]
							})
						]
					})
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						icon: Shirt,
						label: "Squad",
						value: String(players.length),
						hint: "priced players",
						to: "/squad"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						icon: Swords,
						label: teamAName,
						value: creditSum(teamA).toFixed(1),
						hint: `${teamA.length} players · cap ${budget}`,
						to: "/teams"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						icon: Coins,
						label: teamBName,
						value: creditSum(teamB).toFixed(1),
						hint: `${teamB.length} players · cap ${budget}`,
						to: "/teams"
					})
				]
			}),
			completed.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl tracking-tight",
					children: "Recent results"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-2",
					children: completed.slice(0, 4).map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/matches/$matchId",
						params: { matchId: v.match.id },
						className: "flex items-center justify-between gap-3 rounded-xl border border-border bg-surface px-4 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm font-medium",
							children: [
								v.match.teamAName,
								" vs ",
								v.match.teamBName
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: v.result
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 text-faint" })]
					}) }, v.match.id))
				})]
			}) : null
		]
	});
}
function StatCard({ icon: Icon, label, value, hint, to }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to,
		className: "block",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
			className: "h-full",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
							className: "size-4",
							strokeWidth: 1.6
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs uppercase tracking-[0.14em]",
							children: label
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 font-display text-3xl tabular-nums tracking-tight",
						children: value
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted",
						children: hint
					})
				]
			})
		})
	});
}
//#endregion
export { Home as component };
