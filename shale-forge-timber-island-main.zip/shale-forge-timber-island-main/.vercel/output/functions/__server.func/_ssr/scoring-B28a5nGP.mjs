import { f as maxWickets, i as ballsLabel, o as dismissalText, p as opposite } from "./format-BLq0qNgQ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/scoring-B28a5nGP.js
function emptyExtras() {
	return {
		total: 0,
		wides: 0,
		noballs: 0,
		byes: 0,
		legbyes: 0
	};
}
function emptyInnings(index, battingSide, match, target) {
	const batting = battingSide === "A" ? match.teamA : match.teamB;
	const bowling = battingSide === "A" ? match.teamB : match.teamA;
	return {
		index,
		battingSide,
		bowlingSide: opposite(battingSide),
		batting,
		bowling,
		runs: 0,
		wickets: 0,
		legalBalls: 0,
		extras: emptyExtras(),
		batters: [],
		bowlers: [],
		deliveries: [],
		thisOver: [],
		strikerId: null,
		nonStrikerId: null,
		bowlerId: null,
		lastBowlerId: null,
		freeHit: false,
		awaitingOpeners: true,
		awaitingBowler: true,
		awaitingBatsman: false,
		outgoingId: null,
		ended: false,
		endReason: null,
		target,
		partnership: {
			runs: 0,
			balls: 0
		}
	};
}
function ensureBatter(inn, playerId) {
	const existing = inn.batters.find((b) => b.playerId === playerId);
	if (existing) return existing;
	const line = {
		playerId,
		name: inn.batting.find((p) => p.id === playerId)?.name ?? "Batter",
		runs: 0,
		balls: 0,
		fours: 0,
		sixes: 0,
		outText: null,
		battingOrder: inn.batters.length + 1
	};
	inn.batters.push(line);
	return line;
}
function ensureBowler(inn, playerId) {
	const existing = inn.bowlers.find((b) => b.playerId === playerId);
	if (existing) return existing;
	const line = {
		playerId,
		name: inn.bowling.find((p) => p.id === playerId)?.name ?? "Bowler",
		balls: 0,
		maidens: 0,
		runs: 0,
		wickets: 0
	};
	inn.bowlers.push(line);
	return line;
}
function swapStrike(inn) {
	const s = inn.strikerId;
	inn.strikerId = inn.nonStrikerId;
	inn.nonStrikerId = s;
}
function ranForStrike(d) {
	if (d.kind === "wide") return Math.max(0, d.extraRuns - 1);
	if (d.kind === "noball") return d.batRuns;
	if (d.kind === "bye" || d.kind === "legbye") return d.extraRuns;
	return d.batRuns;
}
function bowlerWicket(w) {
	if (!w) return false;
	return w.kind !== "run_out";
}
function bowlerRuns(d) {
	if (d.kind === "bye" || d.kind === "legbye") return 0;
	if (d.kind === "wide" || d.kind === "noball") return d.extraRuns + d.batRuns;
	return d.batRuns;
}
function recomputeMaidens(inn) {
	for (const b of inn.bowlers) b.maidens = 0;
	let overRuns = 0;
	let overBowler = null;
	let legal = 0;
	for (const d of inn.deliveries) {
		if (d.kind === "dead") continue;
		if (overBowler === null) overBowler = d.bowlerId;
		overRuns += bowlerRuns(d);
		if (d.isLegal) {
			legal += 1;
			if (legal === 6) {
				if (overRuns === 0 && overBowler) {
					const line = inn.bowlers.find((b) => b.playerId === overBowler);
					if (line) line.maidens += 1;
				}
				overRuns = 0;
				overBowler = null;
				legal = 0;
			}
		}
	}
}
function recomputeThisOver(inn) {
	const labels = [];
	const startLegal = Math.floor(inn.legalBalls / 6) * 6;
	let seenLegal = 0;
	for (const d of inn.deliveries) {
		if (seenLegal >= startLegal) labels.push(ballsLabel(d));
		if (d.kind === "dead") continue;
		if (d.isLegal) seenLegal += 1;
	}
	inn.thisOver = labels;
}
function recomputePartnership(inn) {
	if (!inn.strikerId || !inn.nonStrikerId) {
		inn.partnership = {
			runs: 0,
			balls: 0
		};
		return;
	}
	const pair = /* @__PURE__ */ new Set([inn.strikerId, inn.nonStrikerId]);
	let runs = 0;
	let balls = 0;
	for (let i = inn.deliveries.length - 1; i >= 0; i -= 1) {
		const d = inn.deliveries[i];
		if (d.kind === "dead") continue;
		if (d.wicket) break;
		if (!(pair.has(d.strikerId) && pair.has(d.nonStrikerId))) break;
		runs += d.batRuns + d.extraRuns;
		if (d.isLegal || d.kind === "noball") balls += 1;
	}
	inn.partnership = {
		runs,
		balls
	};
}
function maybeEndInnings(inn, match) {
	const cap = maxWickets(inn.batting.length);
	if (inn.wickets >= cap) {
		inn.ended = true;
		inn.endReason = "wickets";
	} else if (inn.legalBalls >= match.oversLimit * 6) {
		inn.ended = true;
		inn.endReason = "overs";
	} else if (inn.target != null && inn.runs >= inn.target) {
		inn.ended = true;
		inn.endReason = "target";
	}
	if (inn.ended) {
		inn.awaitingBatsman = false;
		inn.awaitingBowler = false;
		inn.outgoingId = null;
	}
}
function applyDelivery(inn, d, match) {
	if (d.kind === "dead") {
		inn.deliveries.push(d);
		recomputeThisOver(inn);
		return;
	}
	inn.deliveries.push(d);
	inn.freeHit = d.kind === "noball";
	const teamRuns = d.batRuns + d.extraRuns;
	inn.runs += teamRuns;
	inn.extras.total += d.extraRuns;
	if (d.kind === "wide") inn.extras.wides += d.extraRuns;
	if (d.kind === "noball") inn.extras.noballs += d.extraRuns;
	if (d.kind === "bye") inn.extras.byes += d.extraRuns;
	if (d.kind === "legbye") inn.extras.legbyes += d.extraRuns;
	const striker = ensureBatter(inn, d.strikerId);
	ensureBatter(inn, d.nonStrikerId);
	if (d.kind !== "wide") striker.balls += 1;
	striker.runs += d.batRuns;
	if (d.batRuns === 4) striker.fours += 1;
	if (d.batRuns === 6) striker.sixes += 1;
	const bowler = ensureBowler(inn, d.bowlerId);
	if (d.isLegal) bowler.balls += 1;
	bowler.runs += bowlerRuns(d);
	if (bowlerWicket(d.wicket)) bowler.wickets += 1;
	if (d.wicket) {
		inn.wickets += 1;
		const out = ensureBatter(inn, d.wicket.batsmanId);
		const allPlayers = [...inn.batting, ...inn.bowling];
		out.outText = dismissalText(d.wicket, allPlayers, d.bowlerId);
		inn.awaitingBatsman = true;
		inn.outgoingId = d.wicket.batsmanId;
		if (d.wicket.batsmanId === inn.strikerId) inn.strikerId = null;
		else if (d.wicket.batsmanId === inn.nonStrikerId) inn.nonStrikerId = null;
	}
	if (ranForStrike(d) % 2 === 1 && inn.strikerId && inn.nonStrikerId) swapStrike(inn);
	if (d.isLegal) {
		inn.legalBalls += 1;
		if (inn.legalBalls % 6 === 0) {
			if (inn.strikerId && inn.nonStrikerId) swapStrike(inn);
			inn.lastBowlerId = d.bowlerId;
			inn.bowlerId = null;
			inn.awaitingBowler = true;
		}
	}
	maybeEndInnings(inn, match);
	recomputeMaidens(inn);
	recomputeThisOver(inn);
	recomputePartnership(inn);
}
function sendInNewBatsman(inn, batsmanId) {
	ensureBatter(inn, batsmanId);
	if (!inn.strikerId) inn.strikerId = batsmanId;
	else if (!inn.nonStrikerId) inn.nonStrikerId = batsmanId;
	inn.awaitingBatsman = false;
	inn.outgoingId = null;
}
function resultText(match, innings, battingFirst) {
	if (innings.length < 2 || !innings[0]?.ended || !innings[1]?.ended || !battingFirst) return null;
	const first = innings[0];
	const second = innings[1];
	const firstName = battingFirst === "A" ? match.teamAName : match.teamBName;
	const secondName = battingFirst === "A" ? match.teamBName : match.teamAName;
	if (second.runs > first.runs) {
		const remaining = maxWickets(second.batting.length) - second.wickets;
		return `${secondName} won by ${remaining} wicket${remaining === 1 ? "" : "s"}`;
	}
	if (first.runs > second.runs) {
		const by = first.runs - second.runs;
		return `${firstName} won by ${by} run${by === 1 ? "" : "s"}`;
	}
	return "Match tied";
}
function phaseOf(view, match) {
	if (!view.toss) return "scheduled";
	if (view.innings.length === 0) return "openers";
	const live = view.innings.find((i) => !i.ended) ?? view.innings[view.innings.length - 1];
	const first = view.innings[0];
	const second = view.innings[1];
	if (first?.ended && second?.ended) return "complete";
	if (live.ended && view.innings.length === 1) return "innings_break";
	if (live.awaitingOpeners) return "openers";
	if (live.awaitingBatsman) return "new_batsman";
	if (live.awaitingBowler || !live.bowlerId) return "over_change";
	if (!live.strikerId || !live.nonStrikerId) return "openers";
	return "live";
}
function projectMatch(match) {
	let toss = null;
	let battingFirst = null;
	const innings = [];
	const currentOpen = () => innings.find((i) => !i.ended) ?? innings[innings.length - 1];
	for (const ev of match.events) {
		if (ev.type === "toss") {
			toss = ev;
			battingFirst = ev.decision === "bat" ? ev.winner : opposite(ev.winner);
			innings.push(emptyInnings(0, battingFirst, match, null));
			continue;
		}
		const inn = innings[ev.innings];
		if (!inn) continue;
		if (ev.type === "openers") {
			inn.strikerId = ev.strikerId;
			inn.nonStrikerId = ev.nonStrikerId;
			inn.awaitingOpeners = false;
			ensureBatter(inn, ev.strikerId);
			ensureBatter(inn, ev.nonStrikerId);
		} else if (ev.type === "bowler") {
			inn.bowlerId = ev.bowlerId;
			inn.awaitingBowler = false;
			ensureBowler(inn, ev.bowlerId);
		} else if (ev.type === "new_batsman") sendInNewBatsman(inn, ev.batsmanId);
		else if (ev.type === "delivery") applyDelivery(inn, ev.delivery, match);
		else if (ev.type === "end_innings") {
			inn.ended = true;
			inn.endReason = ev.reason;
			inn.awaitingBatsman = false;
			inn.awaitingBowler = false;
		}
		const just = innings[ev.innings];
		if (just?.ended && innings.length === 1 && battingFirst) innings.push(emptyInnings(1, opposite(battingFirst), match, just.runs + 1));
	}
	const first = innings[0];
	if (first?.ended && innings.length === 1 && battingFirst) innings.push(emptyInnings(1, opposite(battingFirst), match, first.runs + 1));
	const base = {
		toss,
		battingFirst,
		innings,
		current: currentOpen() ?? null
	};
	const phase = phaseOf(base, match);
	const result = resultText(match, innings, battingFirst);
	return {
		match,
		phase: result ? "complete" : phase,
		toss,
		battingFirst,
		innings,
		current: base.current,
		result
	};
}
function isLegalKind(kind) {
	return kind === "normal" || kind === "wicket" || kind === "bye" || kind === "legbye";
}
function buildDelivery(input) {
	const extra = input.kind === "wide" || input.kind === "noball" ? Math.max(1, input.extraRuns) : input.kind === "bye" || input.kind === "legbye" ? Math.max(1, input.extraRuns) : 0;
	const bat = input.kind === "wide" || input.kind === "bye" || input.kind === "legbye" ? 0 : input.batRuns;
	return {
		id: input.id,
		kind: input.kind,
		batRuns: bat,
		extraRuns: extra,
		isLegal: isLegalKind(input.kind),
		isFreeHit: input.freeHit,
		strikerId: input.strikerId,
		nonStrikerId: input.nonStrikerId,
		bowlerId: input.bowlerId,
		wicket: input.wicket
	};
}
function yetToBat(inn) {
	const inCard = new Set(inn.batters.map((b) => b.playerId));
	return inn.batting.filter((p) => !inCard.has(p.id));
}
function availableBatsmen(inn) {
	const out = new Set(inn.batters.filter((b) => b.outText).map((b) => b.playerId));
	const occupying = new Set([inn.strikerId, inn.nonStrikerId].filter(Boolean));
	return inn.batting.filter((p) => !out.has(p.id) && !occupying.has(p.id));
}
function availableBowlers(inn) {
	return inn.bowling.filter((p) => p.id !== inn.lastBowlerId);
}
//#endregion
export { yetToBat as a, projectMatch as i, availableBowlers as n, buildDelivery as r, availableBatsmen as t };
