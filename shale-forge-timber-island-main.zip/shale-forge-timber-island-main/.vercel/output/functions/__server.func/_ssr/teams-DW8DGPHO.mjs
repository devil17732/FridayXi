import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { m as ArrowRight, o as Shuffle } from "../_libs/lucide-react.mjs";
import { c as roleLimits, i as cn, l as roleWarnings, o as creditSum, r as useCricketStore, s as roleCounts } from "./router-BmrXQEZs.mjs";
import { c as formatCredits, t as Button } from "./format-BLq0qNgQ.mjs";
import { n as CardContent, t as Card } from "./card-2AIXe0_p.mjs";
import { n as Label, t as Input } from "./label-DFuEgEjq.mjs";
import { t as RoleBadge } from "./role-badge-WQkFGEF3.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/teams-DW8DGPHO.js
var import_jsx_runtime = require_jsx_runtime();
function CreditMeter({ used, budget, label }) {
	const remaining = budget - used;
	const pct = Math.min(100, Math.max(0, used / budget * 100));
	const over = used > budget + .05;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-baseline justify-between gap-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-muted",
					children: label ?? "Credits"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: cn("tabular-nums", over ? "text-danger" : "text-fg"),
					children: [used.toFixed(1), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted",
						children: [" / ", budget.toFixed(0)]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-1.5 overflow-hidden rounded-full bg-surface-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cn("h-full rounded-full", over ? "bg-danger" : "bg-accent"),
					style: { width: `${pct}%` }
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: over ? `${(used - budget).toFixed(1)} over cap` : `${remaining.toFixed(1)} remaining`
			})
		]
	});
}
function TeamsPage() {
	const players = useCricketStore((s) => s.players);
	const selectedIds = useCricketStore((s) => s.selectedIds);
	const teamAIds = useCricketStore((s) => s.teamAIds);
	const teamBIds = useCricketStore((s) => s.teamBIds);
	const teamAName = useCricketStore((s) => s.teamAName);
	const teamBName = useCricketStore((s) => s.teamBName);
	const teamSize = useCricketStore((s) => s.teamSize);
	const budget = useCricketStore((s) => s.budget);
	const toggleSelected = useCricketStore((s) => s.toggleSelected);
	const selectAllPlaying = useCricketStore((s) => s.selectAllPlaying);
	const setTeamName = useCricketStore((s) => s.setTeamName);
	const setTeamSize = useCricketStore((s) => s.setTeamSize);
	const setBudget = useCricketStore((s) => s.setBudget);
	const balanceTeams = useCricketStore((s) => s.balanceTeams);
	const movePlayer = useCricketStore((s) => s.movePlayer);
	const byId = new Map(players.map((p) => [p.id, p]));
	const teamA = teamAIds.map((id) => byId.get(id)).filter((p) => Boolean(p));
	const teamB = teamBIds.map((id) => byId.get(id)).filter((p) => Boolean(p));
	const placed = /* @__PURE__ */ new Set([...teamAIds, ...teamBIds]);
	const bench = players.filter((p) => selectedIds.includes(p.id) && !placed.has(p.id));
	const unused = players.filter((p) => !selectedIds.includes(p.id));
	const diff = Math.abs(creditSum(teamA) - creditSum(teamB));
	const limits = roleLimits(teamSize);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl tracking-tight",
					children: "Sides"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 max-w-xl text-sm text-muted",
					children: "Each XI spends a credit cap. Auto-balance snakes the expensive players so Friday stays competitive."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: balanceTeams,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shuffle, {}), "Auto-balance"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "secondary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/matches",
							children: ["Create match", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "grid gap-4 p-5 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "size",
							children: "Players per side"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "size",
							type: "number",
							min: 6,
							max: 11,
							value: teamSize,
							onChange: (e) => setTeamSize(Math.min(11, Math.max(6, Number(e.target.value) || 11)))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "budget",
							children: "Credit cap"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "budget",
							type: "number",
							min: 50,
							max: 150,
							step: 5,
							value: budget,
							onChange: (e) => setBudget(Number(e.target.value) || 100)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-end",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [
								"Credit gap",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium tabular-nums text-fg",
									children: diff.toFixed(1)
								})
							]
						})
					})
				]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeamColumn, {
					side: "A",
					name: teamAName,
					onName: (n) => setTeamName("A", n),
					players: teamA,
					budget,
					teamSize,
					onMove: movePlayer
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeamColumn, {
					side: "B",
					name: teamBName,
					onName: (n) => setTeamName("B", n),
					players: teamB,
					budget,
					teamSize,
					onMove: movePlayer
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-xl tracking-tight",
							children: "Playing today"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "ghost",
							onClick: selectAllPlaying,
							children: "Select all"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							"Tap a name to include them in the pool. Auto-balance picks",
							" ",
							teamSize * 2,
							" from this list."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "grid gap-2 sm:grid-cols-2",
						children: [...bench, ...unused].map((p) => {
							const on = selectedIds.includes(p.id);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: cn("flex items-center gap-2 rounded-xl border px-3 py-2", on ? "border-border bg-surface" : "border-transparent bg-surface-2/50 opacity-60"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "min-w-0 flex-1 text-left",
									onClick: () => toggleSelected(p.id),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block truncate text-sm font-medium",
										children: p.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-xs text-muted",
										children: [
											p.role,
											" · ",
											formatCredits(p.credits)
										]
									})]
								}), on ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: "outline",
										onClick: () => movePlayer(p.id, "A"),
										children: "A"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: "outline",
										onClick: () => movePlayer(p.id, "B"),
										children: "B"
									})]
								}) : null]
							}) }, p.id);
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-faint",
				children: [
					"Role bands for an XI: WK ",
					limits.WK.min,
					"–",
					limits.WK.max,
					", BAT ",
					limits.BAT.min,
					"–",
					limits.BAT.max,
					", AR ",
					limits.AR.min,
					"–",
					limits.AR.max,
					", BOWL ",
					limits.BOWL.min,
					"–",
					limits.BOWL.max,
					"."
				]
			})
		]
	});
}
function TeamColumn({ side, name, onName, players, budget, teamSize, onMove }) {
	const counts = roleCounts(players);
	const warnings = roleWarnings(players, teamSize);
	const other = side === "A" ? "B" : "A";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
		className: "space-y-4 p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: name,
				onChange: (e) => onName(e.target.value),
				"aria-label": `Team ${side} name`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreditMeter, {
				used: creditSum(players),
				budget
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2 text-xs text-muted",
				children: [Object.keys(counts).map((role) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "rounded-full bg-surface-2 px-2 py-1 tabular-nums",
					children: [
						role,
						" ",
						counts[role]
					]
				}, role)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "rounded-full bg-surface-2 px-2 py-1 tabular-nums",
					children: [
						players.length,
						"/",
						teamSize
					]
				})]
			}),
			warnings.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-danger",
				children: warnings.join(" · ")
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-accent",
				children: "Role mix looks legal"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-1.5",
				children: players.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center gap-2 rounded-lg bg-surface-2 px-3 py-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-10 tabular-nums text-xs text-muted",
							children: formatCredits(p.credits)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "min-w-0 flex-1 truncate text-sm",
							children: p.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoleBadge, { role: p.role }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "text-xs text-muted hover:text-fg",
							onClick: () => onMove(p.id, other),
							children: "Swap"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "text-xs text-muted hover:text-fg",
							onClick: () => onMove(p.id, "bench"),
							children: "Out"
						})
					]
				}, p.id))
			})
		]
	}) });
}
//#endregion
export { TeamsPage as component };
