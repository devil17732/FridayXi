//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Db3zzH4h.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/matches",
			"/squad",
			"/teams"
		],
		preloads: ["/assets/index-Cnx4m5R4.js", "/assets/store-py63_2ef.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Cnx4m5R4.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CY7nPDPi.js",
			"/assets/arrow-right-CqTLoc7G.js",
			"/assets/format-BGnjsLkK.js",
			"/assets/card-DRsLIwJc.js",
			"/assets/scoring-CDNrNeI0.js"
		]
	},
	"/matches": {
		filePath: "/workspace/src/routes/matches.tsx",
		children: ["/matches/$matchId"],
		preloads: [
			"/assets/matches-B0bHPTqt.js",
			"/assets/arrow-right-CqTLoc7G.js",
			"/assets/plus-2_25diN0.js",
			"/assets/format-BGnjsLkK.js",
			"/assets/card-DRsLIwJc.js",
			"/assets/scoring-CDNrNeI0.js",
			"/assets/label-ZNPbdJEx.js"
		]
	},
	"/squad": {
		filePath: "/workspace/src/routes/squad.tsx",
		children: void 0,
		preloads: [
			"/assets/squad-DGF2dV2V.js",
			"/assets/plus-2_25diN0.js",
			"/assets/dialog-Cy4OYjxf.js",
			"/assets/format-BGnjsLkK.js",
			"/assets/card-DRsLIwJc.js",
			"/assets/role-badge-DUm-_rwc.js",
			"/assets/dist-BhkCDdhz.js",
			"/assets/label-ZNPbdJEx.js"
		]
	},
	"/teams": {
		filePath: "/workspace/src/routes/teams.tsx",
		children: void 0,
		preloads: [
			"/assets/teams-B2_0SMjq.js",
			"/assets/arrow-right-CqTLoc7G.js",
			"/assets/format-BGnjsLkK.js",
			"/assets/card-DRsLIwJc.js",
			"/assets/role-badge-DUm-_rwc.js",
			"/assets/label-ZNPbdJEx.js"
		]
	},
	"/matches/$matchId": {
		filePath: "/workspace/src/routes/matches.$matchId.tsx",
		children: void 0,
		preloads: [
			"/assets/matches._matchId-D-6LGgb0.js",
			"/assets/dialog-Cy4OYjxf.js",
			"/assets/role-badge-DUm-_rwc.js",
			"/assets/dist-BhkCDdhz.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
