import { cn } from "@/lib/utils";

export function CreditMeter({
  used,
  budget,
  label,
}: {
  used: number;
  budget: number;
  label?: string;
}) {
  const remaining = budget - used;
  const pct = Math.min(100, Math.max(0, (used / budget) * 100));
  const over = used > budget + 0.05;
  return (
    <div className="space-y-2">
      <div className="flex items-baseline justify-between gap-3 text-sm">
        <span className="text-muted">{label ?? "Credits"}</span>
        <span className={cn("tabular-nums", over ? "text-danger" : "text-fg")}>
          {used.toFixed(1)}
          <span className="text-muted"> / {budget.toFixed(0)}</span>
        </span>
      </div>
      <div className="h-1.5 overflow-hidden rounded-full bg-surface-2">
        <div
          className={cn("h-full rounded-full", over ? "bg-danger" : "bg-accent")}
          style={{ width: `${pct}%` }}
        />
      </div>
      <p className="text-xs text-muted">
        {over ? `${(used - budget).toFixed(1)} over cap` : `${remaining.toFixed(1)} remaining`}
      </p>
    </div>
  );
}
