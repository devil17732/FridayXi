import type { ReactNode } from "react";
import { AppShell } from "@/components/app-shell";
import { useHydrated } from "@/hooks/use-hydrated";

export function HydrateGate({ children }: { children: ReactNode }) {
  useHydrated();
  return <AppShell>{children}</AppShell>;
}
