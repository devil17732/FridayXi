import { useState } from "react";
import { Button } from "@/components/ui/button";
import type { TeamSide } from "@/lib/cricket/types";
import { cn } from "@/lib/utils";

export function CoinToss({
  teamAName,
  teamBName,
  onComplete,
}: {
  teamAName: string;
  teamBName: string;
  onComplete: (result: {
    winner: TeamSide;
    decision: "bat" | "field";
    coin: "heads" | "tails";
  }) => void;
}) {
  const [caller, setCaller] = useState<TeamSide>("A");
  const [call, setCall] = useState<"heads" | "tails">("heads");
  const [flipping, setFlipping] = useState(false);
  const [coin, setCoin] = useState<"heads" | "tails" | null>(null);
  const [flips, setFlips] = useState(8);
  const [winner, setWinner] = useState<TeamSide | null>(null);

  const face = coin ?? "heads";
  const rotate = coin === "tails" ? flips * 360 + 180 : flips * 360;

  return (
    <div className="mx-auto max-w-md space-y-6">
      <div>
        <h2 className="font-display text-2xl tracking-tight">Toss</h2>
        <p className="mt-1 text-sm text-muted">
          Call it in the air. Winner chooses bat or field.
        </p>
      </div>

      <div className="grid grid-cols-2 gap-2">
        <Choice
          active={caller === "A"}
          onClick={() => setCaller("A")}
          disabled={Boolean(coin) || flipping}
          label={teamAName}
          hint="calls"
        />
        <Choice
          active={caller === "B"}
          onClick={() => setCaller("B")}
          disabled={Boolean(coin) || flipping}
          label={teamBName}
          hint="calls"
        />
        <Choice
          active={call === "heads"}
          onClick={() => setCall("heads")}
          disabled={Boolean(coin) || flipping}
          label="Heads"
        />
        <Choice
          active={call === "tails"}
          onClick={() => setCall("tails")}
          disabled={Boolean(coin) || flipping}
          label="Tails"
        />
      </div>

      <div className="flex justify-center py-6">
        <div
          className="coin"
          style={{ transform: `rotateY(${rotate}deg)` }}
          aria-hidden
        >
          <div className="coin-face">
            <span className="font-display text-xl">Heads</span>
          </div>
          <div className="coin-face tails">
            <span className="font-display text-xl">Tails</span>
          </div>
        </div>
      </div>

      {!coin ? (
        <Button
          className="w-full"
          size="lg"
          disabled={flipping}
          onClick={() => {
            const next: "heads" | "tails" = Math.random() < 0.5 ? "heads" : "tails";
            setFlipping(true);
            setFlips((n) => n + 6 + Math.floor(Math.random() * 4));
            window.setTimeout(() => {
              setCoin(next);
              setWinner(next === call ? caller : caller === "A" ? "B" : "A");
              setFlipping(false);
            }, 1600);
          }}
        >
          {flipping ? "In the air…" : "Flip coin"}
        </Button>
      ) : (
        <div className="space-y-4">
          <p className="text-center text-sm text-muted">
            {face === "heads" ? "Heads" : "Tails"}.{" "}
            <span className="text-fg">
              {winner === "A" ? teamAName : teamBName} won the toss.
            </span>
          </p>
          <div className="grid grid-cols-2 gap-2">
            <Button
              size="lg"
              onClick={() =>
                winner && onComplete({ winner, decision: "bat", coin: face })
              }
            >
              Bat
            </Button>
            <Button
              size="lg"
              variant="secondary"
              onClick={() =>
                winner && onComplete({ winner, decision: "field", coin: face })
              }
            >
              Field
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}

function Choice({
  active,
  onClick,
  label,
  hint,
  disabled,
}: {
  active: boolean;
  onClick: () => void;
  label: string;
  hint?: string;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onClick}
      className={cn(
        "min-h-14 rounded-xl border px-3 py-3 text-left transition-colors duration-150",
        active
          ? "border-accent bg-accent/10 text-fg"
          : "border-border bg-surface text-muted",
      )}
    >
      <span className="block truncate text-sm font-medium">{label}</span>
      {hint ? <span className="text-xs text-faint">{hint}</span> : null}
    </button>
  );
}
