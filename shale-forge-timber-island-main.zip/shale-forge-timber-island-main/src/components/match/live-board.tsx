import {
  currentRunRate,
  formatOvers,
  formatRate,
  playerById,
  requiredRunRate,
  strikeRate,
} from "@/lib/cricket/format";
import type { InningsView, MatchView } from "@/lib/cricket/scoring";
import { cn } from "@/lib/utils";

export function LiveBoard({ view, inn }: { view: MatchView; inn: InningsView }) {
  const battingName =
    inn.battingSide === "A" ? view.match.teamAName : view.match.teamBName;
  const crr = currentRunRate(inn.runs, inn.legalBalls);
  const rrr =
    inn.target != null
      ? requiredRunRate(
          inn.runs,
          inn.target,
          inn.legalBalls,
          view.match.oversLimit,
        )
      : null;
  const striker = inn.batters.find((b) => b.playerId === inn.strikerId);
  const non = inn.batters.find((b) => b.playerId === inn.nonStrikerId);
  const bowler = inn.bowlers.find((b) => b.playerId === inn.bowlerId);

  return (
    <div className="space-y-4 rounded-xl border border-border bg-surface p-4 sm:p-5">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-xs uppercase tracking-[0.16em] text-muted">{battingName}</p>
          <p className="mt-1 font-display text-4xl tabular-nums tracking-tight">
            {inn.runs}
            <span className="text-muted">/{inn.wickets}</span>
          </p>
          <p className="mt-1 text-sm text-muted">
            {formatOvers(inn.legalBalls)} ov
            {inn.target != null ? ` · Target ${inn.target}` : ""}
          </p>
        </div>
        <div className="text-right text-xs text-muted">
          <p>
            CRR <span className="tabular-nums text-fg">{formatRate(crr)}</span>
          </p>
          {rrr != null ? (
            <p className="mt-1">
              RRR <span className="tabular-nums text-fg">{formatRate(rrr)}</span>
            </p>
          ) : null}
          {inn.freeHit ? (
            <p className="mt-2 font-medium uppercase tracking-[0.14em] text-accent">
              Free hit
            </p>
          ) : null}
        </div>
      </div>

      <div className="grid gap-2">
        <BatterRow line={striker} nameFallback={playerById(inn.batting, inn.strikerId)?.name} onStrike />
        <BatterRow line={non} nameFallback={playerById(inn.batting, inn.nonStrikerId)?.name} />
      </div>

      {bowler ? (
        <p className="text-sm text-muted">
          {bowler.name}{" "}
          <span className="tabular-nums text-fg">
            {formatOvers(bowler.balls)}–{bowler.maidens}–{bowler.runs}–{bowler.wickets}
          </span>
        </p>
      ) : null}

      <div>
        <p className="text-xs uppercase tracking-[0.14em] text-muted">This over</p>
        <div className="mt-2 flex flex-wrap gap-1.5">
          {inn.thisOver.length === 0 ? (
            <span className="text-sm text-faint">Yet to start</span>
          ) : (
            inn.thisOver.map((ball, i) => (
              <span
                key={`${ball}-${i}`}
                className={cn(
                  "inline-flex min-w-8 items-center justify-center rounded-md px-1.5 py-1 text-xs tabular-nums",
                  ball === "W"
                    ? "bg-danger/20 text-danger"
                    : ball === "4" || ball === "6"
                      ? "bg-accent/20 text-accent"
                      : "bg-surface-2 text-fg",
                )}
              >
                {ball}
              </span>
            ))
          )}
        </div>
      </div>

      <p className="text-xs text-muted">
        Partnership {inn.partnership.runs} ({inn.partnership.balls})
      </p>
    </div>
  );
}

function BatterRow({
  line,
  nameFallback,
  onStrike,
}: {
  line?: { name: string; runs: number; balls: number; fours: number; sixes: number };
  nameFallback?: string;
  onStrike?: boolean;
}) {
  const name = line?.name ?? nameFallback ?? "—";
  const sr = line ? strikeRate(line.runs, line.balls) : 0;
  return (
    <div className="flex items-center justify-between gap-3 rounded-lg bg-surface-2 px-3 py-2 text-sm">
      <span className={cn("truncate", onStrike && "text-accent")}>
        {name}
        {onStrike ? " *" : ""}
      </span>
      <span className="shrink-0 tabular-nums text-muted">
        <span className="text-fg">{line?.runs ?? 0}</span>
        <span className="text-faint"> ({line?.balls ?? 0})</span>
        <span className="ml-2 hidden sm:inline">{formatRate(sr)}</span>
      </span>
    </div>
  );
}
