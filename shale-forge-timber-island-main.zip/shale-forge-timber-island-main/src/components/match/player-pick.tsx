import { Button } from "@/components/ui/button";
import { RoleBadge } from "@/components/role-badge";
import type { MatchPlayer } from "@/lib/cricket/types";
import { cn } from "@/lib/utils";

export function PlayerPick({
  title,
  hint,
  players,
  selected,
  onToggle,
  max = 1,
  confirmLabel,
  onConfirm,
  disabledIds,
}: {
  title: string;
  hint?: string;
  players: MatchPlayer[];
  selected: string[];
  onToggle: (id: string) => void;
  max?: number;
  confirmLabel: string;
  onConfirm: () => void;
  disabledIds?: Set<string>;
}) {
  return (
    <div className="space-y-4">
      <div>
        <h2 className="font-display text-2xl tracking-tight">{title}</h2>
        {hint ? <p className="mt-1 text-sm text-muted">{hint}</p> : null}
      </div>
      <ul className="grid gap-2 sm:grid-cols-2">
        {players.map((p) => {
          const on = selected.includes(p.id);
          const locked = disabledIds?.has(p.id) ?? false;
          return (
            <li key={p.id}>
              <button
                type="button"
                disabled={locked}
                onClick={() => onToggle(p.id)}
                className={cn(
                  "flex w-full min-h-12 items-center justify-between gap-2 rounded-xl border px-3 py-3 text-left",
                  on
                    ? "border-accent bg-accent/10"
                    : "border-border bg-surface",
                  locked && "opacity-40",
                )}
              >
                <span className="truncate text-sm font-medium">{p.name}</span>
                <RoleBadge role={p.role} />
              </button>
            </li>
          );
        })}
      </ul>
      <Button
        className="w-full"
        size="lg"
        disabled={selected.length !== max}
        onClick={onConfirm}
      >
        {confirmLabel}
      </Button>
    </div>
  );
}
