import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  dismissalText,
  economy,
  formatOvers,
  formatRate,
  strikeRate,
} from "@/lib/cricket/format";
import type { InningsView, MatchView } from "@/lib/cricket/scoring";
import { yetToBat } from "@/lib/cricket/scoring";

export function Scorecard({ view }: { view: MatchView }) {
  if (view.innings.length === 0) {
    return <p className="text-sm text-muted">Scorecard opens after the toss.</p>;
  }
  const defaultTab = String(view.innings.length - 1);
  return (
    <Tabs defaultValue={defaultTab}>
      <TabsList className="w-full">
        {view.innings.map((inn, i) => (
          <TabsTrigger key={inn.index} value={String(i)} className="flex-1">
            {inn.battingSide === "A" ? view.match.teamAName : view.match.teamBName}
          </TabsTrigger>
        ))}
      </TabsList>
      {view.innings.map((inn, i) => (
        <TabsContent key={inn.index} value={String(i)}>
          <InningsCard inn={inn} />
        </TabsContent>
      ))}
    </Tabs>
  );
}

function InningsCard({ inn }: { inn: InningsView }) {
  const waiting = yetToBat(inn);
  const allPlayers = [...inn.batting, ...inn.bowling];
  return (
    <div className="space-y-5">
      <p className="font-display text-2xl tabular-nums">
        {inn.runs}/{inn.wickets}{" "}
        <span className="text-base text-muted">({formatOvers(inn.legalBalls)} ov)</span>
      </p>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[28rem] text-left text-sm">
          <thead className="text-xs uppercase tracking-wide text-muted">
            <tr>
              <th className="py-2 font-medium">Batter</th>
              <th className="py-2 font-medium"> </th>
              <th className="py-2 text-right font-medium">R</th>
              <th className="py-2 text-right font-medium">B</th>
              <th className="py-2 text-right font-medium">4</th>
              <th className="py-2 text-right font-medium">6</th>
              <th className="py-2 text-right font-medium">SR</th>
            </tr>
          </thead>
          <tbody>
            {inn.batters.map((b) => {
              const wicketBall = inn.deliveries.find(
                (d) => d.wicket?.batsmanId === b.playerId,
              );
              const how =
                wicketBall?.wicket && wicketBall
                  ? dismissalText(wicketBall.wicket, allPlayers, wicketBall.bowlerId)
                  : "not out";
              return (
                <tr key={b.playerId} className="border-t border-border">
                  <td className="py-2 pr-2 font-medium">{b.name}</td>
                  <td className="py-2 text-xs text-muted">{how}</td>
                  <td className="py-2 text-right tabular-nums">{b.runs}</td>
                  <td className="py-2 text-right tabular-nums text-muted">{b.balls}</td>
                  <td className="py-2 text-right tabular-nums text-muted">{b.fours}</td>
                  <td className="py-2 text-right tabular-nums text-muted">{b.sixes}</td>
                  <td className="py-2 text-right tabular-nums text-muted">
                    {formatRate(strikeRate(b.runs, b.balls))}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      {waiting.length > 0 ? (
        <p className="text-xs text-muted">
          Yet to bat: {waiting.map((p) => p.name).join(", ")}
        </p>
      ) : null}
      <p className="text-xs text-muted">
        Extras {inn.extras.total} (wd {inn.extras.wides}, nb {inn.extras.noballs}, b{" "}
        {inn.extras.byes}, lb {inn.extras.legbyes})
      </p>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[22rem] text-left text-sm">
          <thead className="text-xs uppercase tracking-wide text-muted">
            <tr>
              <th className="py-2 font-medium">Bowler</th>
              <th className="py-2 text-right font-medium">O</th>
              <th className="py-2 text-right font-medium">M</th>
              <th className="py-2 text-right font-medium">R</th>
              <th className="py-2 text-right font-medium">W</th>
              <th className="py-2 text-right font-medium">Econ</th>
            </tr>
          </thead>
          <tbody>
            {inn.bowlers.map((b) => (
              <tr key={b.playerId} className="border-t border-border">
                <td className="py-2 font-medium">{b.name}</td>
                <td className="py-2 text-right tabular-nums">{formatOvers(b.balls)}</td>
                <td className="py-2 text-right tabular-nums">{b.maidens}</td>
                <td className="py-2 text-right tabular-nums">{b.runs}</td>
                <td className="py-2 text-right tabular-nums">{b.wickets}</td>
                <td className="py-2 text-right tabular-nums text-muted">
                  {formatRate(economy(b.runs, b.balls))}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
