import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { DISMISSAL_LABEL } from "@/lib/cricket/format";
import type { InningsView } from "@/lib/cricket/scoring";
import type { DeliveryKind, DismissalKind, WicketInfo } from "@/lib/cricket/types";
import { cn } from "@/lib/utils";

export interface PadPayload {
  kind: DeliveryKind;
  batRuns: number;
  extraRuns: number;
  wicket?: WicketInfo;
}

export function ScoringPad({
  inn,
  onBall,
  onUndo,
  canUndo,
  onEndInnings,
}: {
  inn: InningsView;
  onBall: (payload: PadPayload) => void;
  onUndo: () => void;
  canUndo: boolean;
  onEndInnings: () => void;
}) {
  const [extra, setExtra] = useState<null | "wide" | "noball" | "bye" | "legbye">(null);
  const [wicketOpen, setWicketOpen] = useState(false);
  const [kind, setKind] = useState<DismissalKind>("bowled");
  const [outId, setOutId] = useState(inn.strikerId ?? "");
  const [fielderId, setFielderId] = useState<string>("");

  const needsFielder = kind === "caught" || kind === "run_out" || kind === "stumped";

  return (
    <div className="space-y-3">
      {extra ? (
        <ExtraStrip
          kind={extra}
          onCancel={() => setExtra(null)}
          onPick={(batRuns, extraRuns) => {
            onBall({
              kind: extra,
              batRuns,
              extraRuns,
            });
            setExtra(null);
          }}
        />
      ) : (
        <div className="grid grid-cols-3 gap-2">
          <PadBtn onClick={() => onBall({ kind: "normal", batRuns: 0, extraRuns: 0 })}>
            0
          </PadBtn>
          <PadBtn onClick={() => onBall({ kind: "normal", batRuns: 1, extraRuns: 0 })}>
            1
          </PadBtn>
          <PadBtn onClick={() => onBall({ kind: "normal", batRuns: 2, extraRuns: 0 })}>
            2
          </PadBtn>
          <PadBtn onClick={() => onBall({ kind: "normal", batRuns: 3, extraRuns: 0 })}>
            3
          </PadBtn>
          <PadBtn
            className="bg-accent/15 text-fg"
            onClick={() => onBall({ kind: "normal", batRuns: 4, extraRuns: 0 })}
          >
            4
          </PadBtn>
          <PadBtn
            className="bg-accent/25 text-fg"
            onClick={() => onBall({ kind: "normal", batRuns: 6, extraRuns: 0 })}
          >
            6
          </PadBtn>
          <PadBtn
            className="bg-danger/20 text-danger"
            onClick={() => {
              setOutId(inn.strikerId ?? "");
              setKind("bowled");
              setFielderId("");
              setWicketOpen(true);
            }}
          >
            Wicket
          </PadBtn>
          <PadBtn onClick={() => setExtra("wide")}>Wide</PadBtn>
          <PadBtn onClick={() => setExtra("noball")}>No ball</PadBtn>
          <PadBtn onClick={() => setExtra("bye")}>Bye</PadBtn>
          <PadBtn onClick={() => setExtra("legbye")}>Leg bye</PadBtn>
          <PadBtn
            onClick={() => onBall({ kind: "dead", batRuns: 0, extraRuns: 0 })}
          >
            Dead
          </PadBtn>
        </div>
      )}

      <div className="flex gap-2">
        <Button className="flex-1" variant="outline" disabled={!canUndo} onClick={onUndo}>
          Undo ball
        </Button>
        <Button variant="ghost" onClick={onEndInnings}>
          End innings
        </Button>
      </div>

      <Dialog open={wicketOpen} onOpenChange={setWicketOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Wicket</DialogTitle>
            <DialogDescription>
              How they got out, and who is walking.
            </DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-2">
            {(Object.keys(DISMISSAL_LABEL) as DismissalKind[]).map((k) => (
              <button
                key={k}
                type="button"
                onClick={() => setKind(k)}
                className={cn(
                  "min-h-11 rounded-lg border px-3 text-sm",
                  kind === k
                    ? "border-accent bg-accent/10"
                    : "border-border bg-surface-2",
                )}
              >
                {DISMISSAL_LABEL[k]}
              </button>
            ))}
          </div>
          <p className="text-xs text-muted">Batter out</p>
          <div className="grid grid-cols-2 gap-2">
            {[inn.strikerId, inn.nonStrikerId].filter(Boolean).map((id) => {
              const p = inn.batting.find((x) => x.id === id);
              return (
                <button
                  key={id}
                  type="button"
                  onClick={() => setOutId(id!)}
                  className={cn(
                    "min-h-11 rounded-lg border px-3 text-sm",
                    outId === id
                      ? "border-accent bg-accent/10"
                      : "border-border bg-surface-2",
                  )}
                >
                  {p?.name ?? "Batter"}
                </button>
              );
            })}
          </div>
          {needsFielder ? (
            <>
              <p className="text-xs text-muted">Fielder</p>
              <div className="grid max-h-40 grid-cols-2 gap-2 overflow-y-auto">
                {inn.bowling.map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setFielderId(p.id)}
                    className={cn(
                      "min-h-11 rounded-lg border px-3 text-left text-sm",
                      fielderId === p.id
                        ? "border-accent bg-accent/10"
                        : "border-border bg-surface-2",
                    )}
                  >
                    {p.name}
                  </button>
                ))}
              </div>
            </>
          ) : null}
          <Button
            className="w-full"
            disabled={!outId || (needsFielder && !fielderId)}
            onClick={() => {
              onBall({
                kind: "wicket",
                batRuns: 0,
                extraRuns: 0,
                wicket: {
                  kind,
                  batsmanId: outId,
                  fielderId: needsFielder ? fielderId : undefined,
                },
              });
              setWicketOpen(false);
            }}
          >
            Record wicket
          </Button>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function ExtraStrip({
  kind,
  onCancel,
  onPick,
}: {
  kind: "wide" | "noball" | "bye" | "legbye";
  onCancel: () => void;
  onPick: (batRuns: number, extraRuns: number) => void;
}) {
  const title =
    kind === "wide"
      ? "Wide — extra runs run?"
      : kind === "noball"
        ? "No ball — runs off the bat"
        : kind === "bye"
          ? "Byes"
          : "Leg byes";
  const options =
    kind === "noball"
      ? [0, 1, 2, 3, 4, 6]
      : kind === "wide"
        ? [0, 1, 2, 3, 4]
        : [1, 2, 3, 4];
  return (
    <div className="space-y-2 rounded-xl border border-border bg-surface-2 p-3">
      <div className="flex items-center justify-between">
        <p className="text-sm font-medium">{title}</p>
        <button type="button" className="text-xs text-muted" onClick={onCancel}>
          Cancel
        </button>
      </div>
      <div className="grid grid-cols-3 gap-2">
        {options.map((n) => (
          <PadBtn
            key={n}
            onClick={() => {
              if (kind === "noball") onPick(n, 1);
              else if (kind === "wide") onPick(0, 1 + n);
              else onPick(0, n);
            }}
          >
            {kind === "wide" ? (n === 0 ? "Wide" : `+${n}`) : n}
          </PadBtn>
        ))}
      </div>
    </div>
  );
}

function PadBtn({
  children,
  onClick,
  className,
}: {
  children: React.ReactNode;
  onClick: () => void;
  className?: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "flex h-14 items-center justify-center rounded-xl border border-border bg-surface text-base font-semibold tabular-nums transition-transform duration-150 active:scale-[0.96]",
        className,
      )}
    >
      {children}
    </button>
  );
}
