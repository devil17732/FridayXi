import { Badge } from "@/components/ui/badge";
import type { Role } from "@/lib/cricket/types";

export function RoleBadge({ role }: { role: Role }) {
  return <Badge variant={role === "AR" ? "accent" : "default"}>{role}</Badge>;
}
