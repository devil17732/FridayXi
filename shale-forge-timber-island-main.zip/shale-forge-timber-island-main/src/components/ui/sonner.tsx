import { Toaster as Sonner } from "sonner";

export function Toaster() {
  return (
    <Sonner
      theme="dark"
      position="top-center"
      toastOptions={{
        classNames: {
          toast:
            "bg-surface-2 text-fg border border-border shadow-none font-sans",
          title: "text-fg",
          description: "text-muted",
        },
      }}
    />
  );
}
