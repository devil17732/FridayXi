import { useEffect, useState } from "react";
import { useCricketStore } from "@/lib/store";

export function useHydrated(): boolean {
  const [ok, setOk] = useState(false);

  useEffect(() => {
    const persist = useCricketStore.persist;
    const finish = () => setOk(true);
    const unsub = persist.onFinishHydration(finish);
    void persist.rehydrate();
    if (persist.hasHydrated()) finish();
    return unsub;
  }, []);

  return ok;
}
