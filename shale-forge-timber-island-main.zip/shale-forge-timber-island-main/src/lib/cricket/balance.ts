import type { Player, Role } from "./types";

export type RoleLimits = Record<Role, { min: number; max: number }>;

export function roleLimits(teamSize: number): RoleLimits {
  if (teamSize >= 11) {
    return {
      WK: { min: 1, max: 4 },
      BAT: { min: 3, max: 6 },
      AR: { min: 1, max: 4 },
      BOWL: { min: 3, max: 6 },
    };
  }
  if (teamSize >= 8) {
    return {
      WK: { min: 1, max: 2 },
      BAT: { min: 2, max: 5 },
      AR: { min: 1, max: 3 },
      BOWL: { min: 2, max: 5 },
    };
  }
  return {
    WK: { min: 0, max: 2 },
    BAT: { min: 1, max: 4 },
    AR: { min: 0, max: 3 },
    BOWL: { min: 1, max: 4 },
  };
}

export function roleCounts(players: Player[]): Record<Role, number> {
  const counts: Record<Role, number> = { WK: 0, BAT: 0, AR: 0, BOWL: 0 };
  for (const p of players) counts[p.role] += 1;
  return counts;
}

export function creditSum(players: Player[]): number {
  return players.reduce((s, p) => s + p.credits, 0);
}

export function roleWarnings(players: Player[], teamSize: number): string[] {
  const limits = roleLimits(teamSize);
  const counts = roleCounts(players);
  const warnings: string[] = [];
  (Object.keys(limits) as Role[]).forEach((role) => {
    const { min, max } = limits[role];
    const n = counts[role];
    if (n < min) warnings.push(`Need at least ${min} ${role}`);
    if (n > max) warnings.push(`At most ${max} ${role}`);
  });
  if (players.length > teamSize) warnings.push(`Over XI (${players.length}/${teamSize})`);
  return warnings;
}

function rolePenalty(players: Player[], teamSize: number): number {
  const limits = roleLimits(teamSize);
  const counts = roleCounts(players);
  let p = 0;
  (Object.keys(limits) as Role[]).forEach((role) => {
    const { min, max } = limits[role];
    const n = counts[role];
    if (n < min) p += (min - n) * 6;
    if (n > max) p += (n - max) * 4;
    if (n === 0 && min > 0) p += 8;
  });
  return p;
}

function scoreSplit(
  a: Player[],
  b: Player[],
  teamSize: number,
  budget: number,
): number {
  const diff = Math.abs(creditSum(a) - creditSum(b));
  const over =
    Math.max(0, creditSum(a) - budget) + Math.max(0, creditSum(b) - budget);
  const roles = rolePenalty(a, teamSize) + rolePenalty(b, teamSize);
  const size =
    Math.abs(a.length - teamSize) * 12 + Math.abs(b.length - teamSize) * 12;
  return diff * 10 + over * 8 + roles + size;
}

function assignSnake(players: Player[], size: number): { a: Player[]; b: Player[] } {
  const sorted = [...players].sort(
    (x, y) => y.credits - x.credits || x.name.localeCompare(y.name),
  );
  const a: Player[] = [];
  const b: Player[] = [];
  for (const p of sorted) {
    if (a.length >= size) {
      b.push(p);
      continue;
    }
    if (b.length >= size) {
      a.push(p);
      continue;
    }
    if (a.length !== b.length) {
      (a.length < b.length ? a : b).push(p);
      continue;
    }
    const sa = creditSum(a);
    const sb = creditSum(b);
    (sa <= sb ? a : b).push(p);
  }
  return { a, b };
}

function optimize(
  a: Player[],
  b: Player[],
  teamSize: number,
  budget: number,
): void {
  let best = scoreSplit(a, b, teamSize, budget);
  let improved = true;
  let rounds = 0;
  while (improved && rounds < 8) {
    improved = false;
    rounds += 1;
    for (let i = 0; i < a.length; i += 1) {
      for (let j = 0; j < b.length; j += 1) {
        const tmp = a[i]!;
        a[i] = b[j]!;
        b[j] = tmp;
        const s = scoreSplit(a, b, teamSize, budget);
        if (s + 1e-9 < best) {
          best = s;
          improved = true;
        } else {
          const revert = a[i]!;
          a[i] = b[j]!;
          b[j] = revert;
        }
      }
    }
  }
}

export interface BalanceResult {
  a: Player[];
  b: Player[];
  bench: Player[];
  size: number;
}

export function autoBalance(
  players: Player[],
  teamSize: number,
  budget: number,
): BalanceResult {
  const size = Math.min(teamSize, Math.floor(players.length / 2));
  if (size < 1) {
    return { a: [], b: [], bench: [...players], size: 0 };
  }
  const sorted = [...players].sort(
    (x, y) => y.credits - x.credits || x.name.localeCompare(y.name),
  );
  const selected = sorted.slice(0, size * 2);
  const selectedIds = new Set(selected.map((p) => p.id));
  const bench = players.filter((p) => !selectedIds.has(p.id));
  const { a, b } = assignSnake(selected, size);
  optimize(a, b, size, budget);
  a.sort((x, y) => y.credits - x.credits);
  b.sort((x, y) => y.credits - x.credits);
  return { a, b, bench, size };
}
