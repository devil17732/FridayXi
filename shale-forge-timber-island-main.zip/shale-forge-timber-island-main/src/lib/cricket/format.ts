import type { DismissalKind, MatchPlayer, Role, TeamSide, WicketInfo } from "./types";

export const ROLE_LABEL: Record<Role, string> = {
  WK: "WK",
  BAT: "BAT",
  AR: "AR",
  BOWL: "BOWL",
};

export const ROLE_NAME: Record<Role, string> = {
  WK: "Wicket-keeper",
  BAT: "Batter",
  AR: "All-rounder",
  BOWL: "Bowler",
};

export const DISMISSAL_LABEL: Record<DismissalKind, string> = {
  bowled: "Bowled",
  caught: "Caught",
  lbw: "LBW",
  run_out: "Run out",
  stumped: "Stumped",
  hit_wicket: "Hit wicket",
};

export function formatCredits(n: number): string {
  return n.toFixed(1);
}

export function formatOvers(legalBalls: number): string {
  const overs = Math.floor(legalBalls / 6);
  const balls = legalBalls % 6;
  return `${overs}.${balls}`;
}

export function strikeRate(runs: number, balls: number): number {
  if (balls <= 0) return 0;
  return (runs / balls) * 100;
}

export function economy(runs: number, balls: number): number {
  if (balls <= 0) return 0;
  return (runs / balls) * 6;
}

export function currentRunRate(runs: number, legalBalls: number): number {
  if (legalBalls <= 0) return 0;
  return (runs / legalBalls) * 6;
}

export function requiredRunRate(
  runs: number,
  target: number,
  legalBalls: number,
  oversLimit: number,
): number {
  const remaining = oversLimit * 6 - legalBalls;
  if (remaining <= 0) return 0;
  return ((target - runs) / remaining) * 6;
}

export function formatRate(n: number): string {
  if (!Number.isFinite(n)) return "—";
  return n.toFixed(2);
}

export function playerById(
  players: MatchPlayer[],
  id: string | null | undefined,
): MatchPlayer | undefined {
  if (!id) return undefined;
  return players.find((p) => p.id === id);
}

export function teamName(
  side: TeamSide,
  names: { a: string; b: string },
): string {
  return side === "A" ? names.a : names.b;
}

export function opposite(side: TeamSide): TeamSide {
  return side === "A" ? "B" : "A";
}

export function initials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return "?";
  if (parts.length === 1) return parts[0]!.slice(0, 2).toUpperCase();
  return `${parts[0]![0] ?? ""}${parts[parts.length - 1]![0] ?? ""}`.toUpperCase();
}

export function dismissalText(
  wicket: WicketInfo,
  players: MatchPlayer[],
  bowlerId: string,
): string {
  const bowler = playerById(players, bowlerId)?.name ?? "bowler";
  const fielder = wicket.fielderId
    ? (playerById(players, wicket.fielderId)?.name ?? "fielder")
    : undefined;
  switch (wicket.kind) {
    case "bowled":
      return `b ${bowler}`;
    case "lbw":
      return `lbw b ${bowler}`;
    case "hit_wicket":
      return `hit wicket b ${bowler}`;
    case "caught":
      return fielder ? `c ${fielder} b ${bowler}` : `c & b ${bowler}`;
    case "stumped":
      return fielder ? `st ${fielder} b ${bowler}` : `st b ${bowler}`;
    case "run_out":
      return fielder ? `run out (${fielder})` : "run out";
  }
}

export function formatDateTime(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return new Intl.DateTimeFormat(undefined, {
    weekday: "short",
    day: "numeric",
    month: "short",
    hour: "numeric",
    minute: "2-digit",
  }).format(d);
}

export function ballsLabel(d: {
  kind: string;
  batRuns: number;
  extraRuns: number;
  wicket?: unknown;
}): string {
  if (d.kind === "dead") return "•";
  if (d.wicket) return "W";
  if (d.kind === "wide") return d.extraRuns > 1 ? `wd+${d.extraRuns - 1}` : "wd";
  if (d.kind === "noball") {
    return d.batRuns > 0 ? `nb+${d.batRuns}` : "nb";
  }
  if (d.kind === "bye") return `b${d.extraRuns}`;
  if (d.kind === "legbye") return `lb${d.extraRuns}`;
  if (d.batRuns === 0) return ".";
  return String(d.batRuns);
}

export function maxWickets(teamSize: number): number {
  return Math.max(1, teamSize - 1);
}
