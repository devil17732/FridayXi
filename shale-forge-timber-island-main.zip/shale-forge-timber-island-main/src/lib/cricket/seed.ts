import type { Player } from "./types";

export const SEED_PLAYERS: Player[] = [
  { id: "p01", name: "Rohan Mehta", role: "WK", credits: 9.0 },
  { id: "p02", name: "Kabir Shah", role: "WK", credits: 8.0 },
  { id: "p03", name: "Dev Patel", role: "WK", credits: 7.0 },
  { id: "p04", name: "Arjun Rao", role: "BAT", credits: 10.5 },
  { id: "p05", name: "Vikram Singh", role: "BAT", credits: 10.0 },
  { id: "p06", name: "Neil Kapoor", role: "BAT", credits: 9.0 },
  { id: "p07", name: "Sameer Joshi", role: "BAT", credits: 8.5 },
  { id: "p08", name: "Farhan Ali", role: "BAT", credits: 8.0 },
  { id: "p09", name: "Ishaan Verma", role: "BAT", credits: 7.5 },
  { id: "p10", name: "Mohit Nair", role: "BAT", credits: 7.0 },
  { id: "p11", name: "Yash Bhatia", role: "BAT", credits: 6.5 },
  { id: "p12", name: "Karan Malhotra", role: "AR", credits: 9.5 },
  { id: "p13", name: "Aditya Reddy", role: "AR", credits: 8.5 },
  { id: "p14", name: "Rehan Khan", role: "AR", credits: 8.0 },
  { id: "p15", name: "Nikhil Desai", role: "AR", credits: 7.0 },
  { id: "p16", name: "Varun Iyer", role: "AR", credits: 6.5 },
  { id: "p17", name: "Pranav Iyer", role: "BOWL", credits: 9.0 },
  { id: "p18", name: "Sohail Ahmed", role: "BOWL", credits: 8.5 },
  { id: "p19", name: "Rajat Gupta", role: "BOWL", credits: 8.0 },
  { id: "p20", name: "Ankit Sharma", role: "BOWL", credits: 7.5 },
  { id: "p21", name: "Harsh Vora", role: "BOWL", credits: 7.0 },
  { id: "p22", name: "Tushar Menon", role: "BOWL", credits: 6.5 },
  { id: "p23", name: "Aman Gill", role: "BOWL", credits: 6.0 },
  { id: "p24", name: "Piyush Jain", role: "BOWL", credits: 5.5 },
];

export const DEFAULT_TEAM_A = "Pavilion";
export const DEFAULT_TEAM_B = "Nursery";
export const DEFAULT_BUDGET = 100;
export const DEFAULT_TEAM_SIZE = 11;
export const DEFAULT_OVERS = 20;
