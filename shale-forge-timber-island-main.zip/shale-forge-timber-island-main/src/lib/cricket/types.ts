export type Role = "WK" | "BAT" | "AR" | "BOWL";
export type TeamSide = "A" | "B";

export interface Player {
  id: string;
  name: string;
  role: Role;
  credits: number;
}

export interface MatchPlayer {
  id: string;
  name: string;
  role: Role;
  credits: number;
}

export type DismissalKind =
  | "bowled"
  | "caught"
  | "lbw"
  | "run_out"
  | "stumped"
  | "hit_wicket";

export type DeliveryKind =
  | "normal"
  | "wicket"
  | "wide"
  | "noball"
  | "bye"
  | "legbye"
  | "dead";

export interface WicketInfo {
  kind: DismissalKind;
  batsmanId: string;
  fielderId?: string;
}

export interface Delivery {
  id: string;
  kind: DeliveryKind;
  batRuns: number;
  extraRuns: number;
  isLegal: boolean;
  isFreeHit: boolean;
  strikerId: string;
  nonStrikerId: string;
  bowlerId: string;
  wicket?: WicketInfo;
}

export type MatchEvent =
  | {
      id: string;
      type: "toss";
      winner: TeamSide;
      decision: "bat" | "field";
      coin: "heads" | "tails";
    }
  | {
      id: string;
      type: "openers";
      innings: 0 | 1;
      strikerId: string;
      nonStrikerId: string;
    }
  | {
      id: string;
      type: "bowler";
      innings: 0 | 1;
      bowlerId: string;
    }
  | {
      id: string;
      type: "new_batsman";
      innings: 0 | 1;
      batsmanId: string;
    }
  | {
      id: string;
      type: "delivery";
      innings: 0 | 1;
      delivery: Delivery;
    }
  | {
      id: string;
      type: "end_innings";
      innings: 0 | 1;
      reason: "overs" | "wickets" | "target" | "manual";
    };

export interface Match {
  id: string;
  createdAt: string;
  venue: string;
  startTime: string;
  oversLimit: number;
  teamAName: string;
  teamBName: string;
  teamA: MatchPlayer[];
  teamB: MatchPlayer[];
  captainAId: string;
  captainBId: string;
  events: MatchEvent[];
}

export type MatchPhase =
  | "scheduled"
  | "openers"
  | "bowler"
  | "live"
  | "new_batsman"
  | "over_change"
  | "innings_break"
  | "complete";
