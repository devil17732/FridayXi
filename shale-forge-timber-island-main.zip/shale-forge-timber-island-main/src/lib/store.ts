import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import { autoBalance } from "@/lib/cricket/balance";
import {
  DEFAULT_BUDGET,
  DEFAULT_TEAM_A,
  DEFAULT_TEAM_B,
  DEFAULT_TEAM_SIZE,
  SEED_PLAYERS,
} from "@/lib/cricket/seed";
import type {
  Match,
  MatchEvent,
  Player,
  Role,
  TeamSide,
} from "@/lib/cricket/types";
import { uid } from "@/lib/utils";

export type Destination = TeamSide | "bench";

interface CricketState {
  players: Player[];
  selectedIds: string[];
  teamAIds: string[];
  teamBIds: string[];
  teamAName: string;
  teamBName: string;
  teamSize: number;
  budget: number;
  matches: Match[];

  addPlayer: (input: { name: string; role: Role; credits: number }) => void;
  updatePlayer: (id: string, patch: Partial<Omit<Player, "id">>) => void;
  removePlayer: (id: string) => void;
  toggleSelected: (id: string) => void;
  selectAllPlaying: () => void;
  setTeamName: (side: TeamSide, name: string) => void;
  setTeamSize: (n: number) => void;
  setBudget: (n: number) => void;
  balanceTeams: () => void;
  movePlayer: (id: string, to: Destination) => void;
  restoreDemoSquad: () => void;
  createMatch: (input: {
    venue: string;
    startTime: string;
    oversLimit: number;
  }) => string;
  deleteMatch: (id: string) => void;
  pushEvent: (matchId: string, event: MatchEvent) => void;
  undoEvent: (matchId: string) => void;
}

function snapshotPlayers(ids: string[], players: Player[]) {
  return ids
    .map((id) => players.find((p) => p.id === id))
    .filter((p): p is Player => Boolean(p))
    .map((p) => ({ id: p.id, name: p.name, role: p.role, credits: p.credits }));
}

function initialBalance() {
  const result = autoBalance(SEED_PLAYERS, DEFAULT_TEAM_SIZE, DEFAULT_BUDGET);
  return {
    teamAIds: result.a.map((p) => p.id),
    teamBIds: result.b.map((p) => p.id),
  };
}

const seeded = initialBalance();

export const useCricketStore = create<CricketState>()(
  persist(
    (set, get) => ({
      players: SEED_PLAYERS,
      selectedIds: SEED_PLAYERS.map((p) => p.id),
      teamAIds: seeded.teamAIds,
      teamBIds: seeded.teamBIds,
      teamAName: DEFAULT_TEAM_A,
      teamBName: DEFAULT_TEAM_B,
      teamSize: DEFAULT_TEAM_SIZE,
      budget: DEFAULT_BUDGET,
      matches: [],

      addPlayer: (input) => {
        const player: Player = { id: uid(), ...input };
        set((s) => ({
          players: [...s.players, player],
          selectedIds: [...s.selectedIds, player.id],
        }));
      },

      updatePlayer: (id, patch) => {
        set((s) => ({
          players: s.players.map((p) => (p.id === id ? { ...p, ...patch } : p)),
        }));
      },

      removePlayer: (id) => {
        set((s) => ({
          players: s.players.filter((p) => p.id !== id),
          selectedIds: s.selectedIds.filter((x) => x !== id),
          teamAIds: s.teamAIds.filter((x) => x !== id),
          teamBIds: s.teamBIds.filter((x) => x !== id),
        }));
      },

      toggleSelected: (id) => {
        set((s) => {
          const on = s.selectedIds.includes(id);
          const selectedIds = on
            ? s.selectedIds.filter((x) => x !== id)
            : [...s.selectedIds, id];
          return { selectedIds };
        });
      },

      selectAllPlaying: () => {
        set((s) => ({ selectedIds: s.players.map((p) => p.id) }));
      },

      setTeamName: (side, name) => {
        set(side === "A" ? { teamAName: name } : { teamBName: name });
      },

      setTeamSize: (n) => set({ teamSize: n }),
      setBudget: (n) => set({ budget: n }),

      balanceTeams: () => {
        const s = get();
        const pool = s.players.filter((p) => s.selectedIds.includes(p.id));
        const result = autoBalance(pool, s.teamSize, s.budget);
        set({
          teamAIds: result.a.map((p) => p.id),
          teamBIds: result.b.map((p) => p.id),
        });
      },

      movePlayer: (id, to) => {
        set((s) => {
          const teamAIds = s.teamAIds.filter((x) => x !== id);
          const teamBIds = s.teamBIds.filter((x) => x !== id);
          if (to === "A") teamAIds.push(id);
          if (to === "B") teamBIds.push(id);
          const selectedIds = s.selectedIds.includes(id)
            ? s.selectedIds
            : [...s.selectedIds, id];
          return { teamAIds, teamBIds, selectedIds };
        });
      },

      restoreDemoSquad: () => {
        const next = autoBalance(SEED_PLAYERS, DEFAULT_TEAM_SIZE, DEFAULT_BUDGET);
        set({
          players: SEED_PLAYERS,
          selectedIds: SEED_PLAYERS.map((p) => p.id),
          teamAIds: next.a.map((p) => p.id),
          teamBIds: next.b.map((p) => p.id),
          teamAName: DEFAULT_TEAM_A,
          teamBName: DEFAULT_TEAM_B,
          teamSize: DEFAULT_TEAM_SIZE,
          budget: DEFAULT_BUDGET,
        });
      },

      createMatch: ({ venue, startTime, oversLimit }) => {
        const s = get();
        const teamA = snapshotPlayers(s.teamAIds, s.players);
        const teamB = snapshotPlayers(s.teamBIds, s.players);
        const match: Match = {
          id: uid(),
          createdAt: new Date().toISOString(),
          venue: venue.trim() || "Local ground",
          startTime,
          oversLimit,
          teamAName: s.teamAName.trim() || DEFAULT_TEAM_A,
          teamBName: s.teamBName.trim() || DEFAULT_TEAM_B,
          teamA,
          teamB,
          captainAId: teamA[0]?.id ?? "",
          captainBId: teamB[0]?.id ?? "",
          events: [],
        };
        set({ matches: [match, ...s.matches] });
        return match.id;
      },

      deleteMatch: (id) => {
        set((s) => ({ matches: s.matches.filter((m) => m.id !== id) }));
      },

      pushEvent: (matchId, event) => {
        set((s) => ({
          matches: s.matches.map((m) =>
            m.id === matchId ? { ...m, events: [...m.events, event] } : m,
          ),
        }));
      },

      undoEvent: (matchId) => {
        set((s) => ({
          matches: s.matches.map((m) =>
            m.id === matchId ? { ...m, events: m.events.slice(0, -1) } : m,
          ),
        }));
      },
    }),
    {
      name: "friday-xi-v1",
      storage: createJSONStorage(() => {
        if (typeof window === "undefined") {
          return {
            getItem: () => null,
            setItem: () => {},
            removeItem: () => {},
          };
        }
        return localStorage;
      }),
      skipHydration: true,
      partialize: (s) => ({
        players: s.players,
        selectedIds: s.selectedIds,
        teamAIds: s.teamAIds,
        teamBIds: s.teamBIds,
        teamAName: s.teamAName,
        teamBName: s.teamBName,
        teamSize: s.teamSize,
        budget: s.budget,
        matches: s.matches,
      }),
    },
  ),
);
