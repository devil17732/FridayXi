import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Coins, Shirt, Swords } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { creditSum } from "@/lib/cricket/balance";
import { formatDateTime, formatOvers } from "@/lib/cricket/format";
import { projectMatch } from "@/lib/cricket/scoring";
import { useCricketStore } from "@/lib/store";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const players = useCricketStore((s) => s.players);
  const teamAIds = useCricketStore((s) => s.teamAIds);
  const teamBIds = useCricketStore((s) => s.teamBIds);
  const teamAName = useCricketStore((s) => s.teamAName);
  const teamBName = useCricketStore((s) => s.teamBName);
  const matches = useCricketStore((s) => s.matches);
  const budget = useCricketStore((s) => s.budget);

  const teamA = players.filter((p) => teamAIds.includes(p.id));
  const teamB = players.filter((p) => teamBIds.includes(p.id));
  const live = matches
    .map(projectMatch)
    .find((v) => v.phase !== "complete" && v.phase !== "scheduled");
  const next = matches
    .map((m) => ({ m, v: projectMatch(m) }))
    .find((x) => x.v.phase === "scheduled");
  const completed = matches.map(projectMatch).filter((v) => v.phase === "complete");

  return (
    <div className="space-y-8">
      <section className="stumps rise-in rounded-xl border border-border bg-surface px-5 py-8 sm:px-8 sm:py-10">
        <p className="text-xs font-medium uppercase tracking-[0.18em] text-accent">
          Weekly cricket
        </p>
        <h1 className="mt-3 max-w-lg font-display text-4xl font-medium leading-tight tracking-tight text-fg sm:text-5xl">
          Fair sides. A proper toss. Every ball in the book.
        </h1>
        <p className="mt-4 max-w-md text-sm leading-relaxed text-muted">
          Price the squad like Dream11, split two XIs on a credit cap, then
          score the Friday game over by over.
        </p>
        <div className="mt-6 flex flex-wrap gap-3">
          <Button asChild>
            <Link to="/teams">
              Balance sides
              <ArrowRight />
            </Link>
          </Button>
          <Button asChild variant="secondary">
            <Link to="/matches">Open matches</Link>
          </Button>
        </div>
      </section>

      {live ? (
        <Link to="/matches/$matchId" params={{ matchId: live.match.id }} className="block">
          <Card className="rise-in-2 overflow-hidden">
            <CardContent className="p-5">
              <p className="text-xs uppercase tracking-[0.16em] text-accent">Live</p>
              <p className="mt-2 font-display text-2xl tracking-tight">
                {live.match.teamAName}{" "}
                <span className="text-muted">vs</span> {live.match.teamBName}
              </p>
              {live.current ? (
                <p className="mt-3 font-display text-3xl tabular-nums">
                  {live.current.runs}/{live.current.wickets}{" "}
                  <span className="text-lg text-muted">
                    ({formatOvers(live.current.legalBalls)})
                  </span>
                </p>
              ) : (
                <p className="mt-3 text-sm text-muted">Toss and openers next.</p>
              )}
            </CardContent>
          </Card>
        </Link>
      ) : next ? (
        <Link to="/matches/$matchId" params={{ matchId: next.m.id }} className="block">
          <Card className="rise-in-2">
            <CardContent className="p-5">
              <p className="text-xs uppercase tracking-[0.16em] text-muted">Next up</p>
              <p className="mt-2 font-display text-2xl tracking-tight">
                {next.m.teamAName} vs {next.m.teamBName}
              </p>
              <p className="mt-2 text-sm text-muted">
                {formatDateTime(next.m.startTime)} · {next.m.venue}
              </p>
            </CardContent>
          </Card>
        </Link>
      ) : null}

      <section className="grid gap-3 sm:grid-cols-3">
        <StatCard
          icon={Shirt}
          label="Squad"
          value={String(players.length)}
          hint="priced players"
          to="/squad"
        />
        <StatCard
          icon={Swords}
          label={teamAName}
          value={creditSum(teamA).toFixed(1)}
          hint={`${teamA.length} players · cap ${budget}`}
          to="/teams"
        />
        <StatCard
          icon={Coins}
          label={teamBName}
          value={creditSum(teamB).toFixed(1)}
          hint={`${teamB.length} players · cap ${budget}`}
          to="/teams"
        />
      </section>

      {completed.length > 0 ? (
        <section className="space-y-3">
          <h2 className="font-display text-xl tracking-tight">Recent results</h2>
          <ul className="space-y-2">
            {completed.slice(0, 4).map((v) => (
              <li key={v.match.id}>
                <Link
                  to="/matches/$matchId"
                  params={{ matchId: v.match.id }}
                  className="flex items-center justify-between gap-3 rounded-xl border border-border bg-surface px-4 py-3"
                >
                  <div>
                    <p className="text-sm font-medium">
                      {v.match.teamAName} vs {v.match.teamBName}
                    </p>
                    <p className="text-xs text-muted">{v.result}</p>
                  </div>
                  <ArrowRight className="size-4 text-faint" />
                </Link>
              </li>
            ))}
          </ul>
        </section>
      ) : null}
    </div>
  );
}

function StatCard({
  icon: Icon,
  label,
  value,
  hint,
  to,
}: {
  icon: typeof Shirt;
  label: string;
  value: string;
  hint: string;
  to: "/" | "/squad" | "/teams" | "/matches";
}) {
  return (
    <Link to={to} className="block">
      <Card className="h-full">
        <CardContent className="p-5">
          <div className="flex items-center gap-2 text-muted">
            <Icon className="size-4" strokeWidth={1.6} />
            <span className="text-xs uppercase tracking-[0.14em]">{label}</span>
          </div>
          <p className="mt-3 font-display text-3xl tabular-nums tracking-tight">{value}</p>
          <p className="mt-1 text-xs text-muted">{hint}</p>
        </CardContent>
      </Card>
    </Link>
  );
}
