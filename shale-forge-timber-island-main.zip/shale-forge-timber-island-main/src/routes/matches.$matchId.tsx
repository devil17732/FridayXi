import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { CoinToss } from "@/components/match/coin-toss";
import { LiveBoard } from "@/components/match/live-board";
import { PlayerPick } from "@/components/match/player-pick";
import { Scorecard } from "@/components/match/scorecard";
import { ScoringPad, type PadPayload } from "@/components/match/scoring-pad";
import { Button } from "@/components/ui/button";
import { formatDateTime } from "@/lib/cricket/format";
import {
  availableBatsmen,
  availableBowlers,
  buildDelivery,
  projectMatch,
} from "@/lib/cricket/scoring";
import { useCricketStore } from "@/lib/store";
import { uid } from "@/lib/utils";

export const Route = createFileRoute("/matches/$matchId")({
  component: MatchPage,
});

function MatchPage() {
  const { matchId } = Route.useParams();
  const match = useCricketStore((s) => s.matches.find((m) => m.id === matchId));
  const pushEvent = useCricketStore((s) => s.pushEvent);
  const undoEvent = useCricketStore((s) => s.undoEvent);
  const deleteMatch = useCricketStore((s) => s.deleteMatch);
  const view = useMemo(() => (match ? projectMatch(match) : null), [match]);
  const [picked, setPicked] = useState<string[]>([]);
  const [tab, setTab] = useState<"score" | "card">("score");

  if (!match || !view) {
    return (
      <div className="space-y-3">
        <p className="text-sm text-muted">That match is not on the book.</p>
        <Button asChild variant="secondary">
          <Link to="/matches">Back to matches</Link>
        </Button>
      </div>
    );
  }

  const inn = view.current;
  const inningsIndex = (inn?.index ?? 0) as 0 | 1;

  const togglePick = (id: string, max: number) => {
    setPicked((cur) => {
      if (cur.includes(id)) return cur.filter((x) => x !== id);
      if (cur.length >= max) return [...cur.slice(1), id];
      return [...cur, id];
    });
  };

  const recordBall = (payload: PadPayload) => {
    if (!inn || !inn.strikerId || !inn.nonStrikerId || !inn.bowlerId) return;
    if (inn.freeHit && payload.wicket && payload.wicket.kind !== "run_out") {
      toast.error("Free hit — only a run out can fall.");
      return;
    }
    const delivery = buildDelivery({
      id: uid(),
      kind: payload.kind,
      batRuns: payload.batRuns,
      extraRuns: payload.extraRuns,
      strikerId: inn.strikerId,
      nonStrikerId: inn.nonStrikerId,
      bowlerId: inn.bowlerId,
      freeHit: inn.freeHit,
      wicket: payload.wicket,
    });
    pushEvent(match.id, {
      id: uid(),
      type: "delivery",
      innings: inningsIndex,
      delivery,
    });
  };

  return (
    <div className="space-y-5">
      <div className="flex items-start justify-between gap-3">
        <div>
          <Link
            to="/matches"
            className="inline-flex items-center gap-1 text-xs text-muted hover:text-fg"
          >
            <ArrowLeft className="size-3.5" />
            Matches
          </Link>
          <h1 className="mt-2 font-display text-2xl tracking-tight sm:text-3xl">
            {match.teamAName} vs {match.teamBName}
          </h1>
          <p className="mt-1 text-sm text-muted">
            {match.venue} · {formatDateTime(match.startTime)} · {match.oversLimit} ov
          </p>
        </div>
        {view.phase !== "complete" && match.events.length > 0 ? (
          <Button variant="ghost" size="sm" onClick={() => undoEvent(match.id)}>
            Undo
          </Button>
        ) : null}
      </div>

      {view.toss ? (
        <p className="text-sm text-muted">
          {(view.toss.winner === "A" ? match.teamAName : match.teamBName)} won the toss
          and chose to {view.toss.decision}.
        </p>
      ) : null}

      {view.result ? (
        <p className="rounded-xl border border-border bg-surface px-4 py-3 font-display text-xl">
          {view.result}
        </p>
      ) : null}

      {view.phase !== "scheduled" ? (
        <div className="flex gap-2">
          <Button
            size="sm"
            variant={tab === "score" ? "default" : "outline"}
            onClick={() => setTab("score")}
          >
            Scoring
          </Button>
          <Button
            size="sm"
            variant={tab === "card" ? "default" : "outline"}
            onClick={() => setTab("card")}
          >
            Scorecard
          </Button>
        </div>
      ) : null}

      {tab === "card" && view.phase !== "scheduled" ? (
        <Scorecard view={view} />
      ) : (
        <>
          {inn && view.phase !== "scheduled" && view.phase !== "openers" ? (
            <LiveBoard view={view} inn={inn} />
          ) : null}

          {view.phase === "scheduled" ? (
            <CoinToss
              teamAName={match.teamAName}
              teamBName={match.teamBName}
              onComplete={(result) => {
                pushEvent(match.id, { id: uid(), type: "toss", ...result });
                setPicked([]);
              }}
            />
          ) : null}

          {view.phase === "openers" && inn ? (
            <PlayerPick
              title={
                inn.index === 1
                  ? `Chase ${inn.target ?? ""}`
                  : "Openers"
              }
              hint={
                inn.index === 1
                  ? `Need ${inn.target} to win. Pick the striker first, then the non-striker.`
                  : "Pick the striker first, then the non-striker."
              }
              players={availableBatsmen(inn).length ? availableBatsmen(inn) : inn.batting}
              selected={picked}
              max={2}
              confirmLabel="Confirm openers"
              onToggle={(id) => togglePick(id, 2)}
              onConfirm={() => {
                if (picked.length !== 2) return;
                pushEvent(match.id, {
                  id: uid(),
                  type: "openers",
                  innings: inningsIndex,
                  strikerId: picked[0]!,
                  nonStrikerId: picked[1]!,
                });
                setPicked([]);
              }}
            />
          ) : null}

          {view.phase === "new_batsman" && inn ? (
            <PlayerPick
              title="New batter"
              hint="Who is walking in?"
              players={availableBatsmen(inn)}
              selected={picked}
              max={1}
              confirmLabel="Send in"
              onToggle={(id) => togglePick(id, 1)}
              onConfirm={() => {
                if (!picked[0]) return;
                pushEvent(match.id, {
                  id: uid(),
                  type: "new_batsman",
                  innings: inningsIndex,
                  batsmanId: picked[0],
                });
                setPicked([]);
              }}
            />
          ) : null}

          {(view.phase === "over_change" ||
            (view.phase === "live" && inn && !inn.bowlerId)) &&
          inn ? (
            <PlayerPick
              title={inn.legalBalls === 0 ? "Opening bowler" : "Next bowler"}
              hint="A bowler cannot bowl consecutive overs."
              players={availableBowlers(inn)}
              selected={picked}
              max={1}
              confirmLabel="Confirm bowler"
              disabledIds={inn.lastBowlerId ? new Set([inn.lastBowlerId]) : undefined}
              onToggle={(id) => togglePick(id, 1)}
              onConfirm={() => {
                if (!picked[0]) return;
                pushEvent(match.id, {
                  id: uid(),
                  type: "bowler",
                  innings: inningsIndex,
                  bowlerId: picked[0],
                });
                setPicked([]);
              }}
            />
          ) : null}

          {view.phase === "innings_break" && inn ? (
            <div className="space-y-3 rounded-xl border border-border bg-surface p-5">
              <h2 className="font-display text-xl">Innings break</h2>
              <p className="text-sm text-muted">
                {inn.runs}/{inn.wickets} on the board. Open the chase when the
                field is set.
              </p>
              <p className="text-xs text-muted">
                The second innings opens automatically — pick the new openers
                below once you continue.
              </p>
            </div>
          ) : null}

          {view.phase === "live" && inn && inn.bowlerId && inn.strikerId ? (
            <ScoringPad
              inn={inn}
              onBall={recordBall}
              onUndo={() => undoEvent(match.id)}
              canUndo={match.events.length > 0}
              onEndInnings={() => {
                pushEvent(match.id, {
                  id: uid(),
                  type: "end_innings",
                  innings: inningsIndex,
                  reason: "manual",
                });
              }}
            />
          ) : null}

          {view.phase === "complete" ? <Scorecard view={view} /> : null}
        </>
      )}

      {view.phase === "complete" ? (
        <Button
          variant="ghost"
          size="sm"
          onClick={() => deleteMatch(match.id)}
        >
          Remove from book
        </Button>
      ) : null}
    </div>
  );
}
