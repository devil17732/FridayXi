import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { ArrowRight, MapPin, Plus } from "lucide-react";
import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { formatDateTime, formatOvers } from "@/lib/cricket/format";
import { DEFAULT_OVERS } from "@/lib/cricket/seed";
import { projectMatch } from "@/lib/cricket/scoring";
import { useCricketStore } from "@/lib/store";

export const Route = createFileRoute("/matches/")({ component: MatchesPage });

function nextFridayEvening(): string {
  const d = new Date();
  const day = d.getDay();
  const days = day === 5 ? 0 : (5 - day + 7) % 7;
  d.setDate(d.getDate() + days);
  d.setHours(18, 30, 0, 0);
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function MatchesPage() {
  const matches = useCricketStore((s) => s.matches);
  const createMatch = useCricketStore((s) => s.createMatch);
  const teamAName = useCricketStore((s) => s.teamAName);
  const teamBName = useCricketStore((s) => s.teamBName);
  const teamAIds = useCricketStore((s) => s.teamAIds);
  const teamBIds = useCricketStore((s) => s.teamBIds);
  const navigate = useNavigate();
  const [venue, setVenue] = useState("Club ground");
  const [startTime, setStartTime] = useState(nextFridayEvening);
  const [overs, setOvers] = useState(String(DEFAULT_OVERS));

  const views = useMemo(() => matches.map(projectMatch), [matches]);
  const canCreate = teamAIds.length >= 2 && teamBIds.length >= 2;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl tracking-tight">Matches</h1>
        <p className="mt-1 text-sm text-muted">
          {teamAName} vs {teamBName} — set the ground and start scoring.
        </p>
      </div>

      <Card>
        <CardContent className="space-y-4 p-5">
          <div className="grid gap-3 sm:grid-cols-3">
            <div className="space-y-1.5 sm:col-span-1">
              <Label htmlFor="venue">Venue</Label>
              <Input
                id="venue"
                value={venue}
                onChange={(e) => setVenue(e.target.value)}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="when">When</Label>
              <Input
                id="when"
                type="datetime-local"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="overs">Overs</Label>
              <Input
                id="overs"
                type="number"
                min={5}
                max={50}
                value={overs}
                onChange={(e) => setOvers(e.target.value)}
              />
            </div>
          </div>
          <Button
            disabled={!canCreate}
            onClick={() => {
              const id = createMatch({
                venue,
                startTime: new Date(startTime).toISOString(),
                oversLimit: Math.min(50, Math.max(5, Number(overs) || 20)),
              });
              void navigate({ to: "/matches/$matchId", params: { matchId: id } });
            }}
          >
            <Plus />
            Create match
          </Button>
          {!canCreate ? (
            <p className="text-xs text-muted">
              Balance two sides first — each team needs at least two players.
            </p>
          ) : null}
        </CardContent>
      </Card>

      {views.length === 0 ? (
        <p className="text-sm text-muted">No matches yet. Create this Friday’s fixture.</p>
      ) : (
        <ul className="space-y-2">
          {views.map((v) => (
            <li key={v.match.id}>
              <Link
                to="/matches/$matchId"
                params={{ matchId: v.match.id }}
                className="flex items-center justify-between gap-3 rounded-xl border border-border bg-surface px-4 py-4"
              >
                <div className="min-w-0">
                  <p className="font-medium">
                    {v.match.teamAName} vs {v.match.teamBName}
                  </p>
                  <p className="mt-1 flex flex-wrap items-center gap-x-2 text-xs text-muted">
                    <MapPin className="size-3" />
                    {v.match.venue}
                    <span>· {formatDateTime(v.match.startTime)}</span>
                    <span>· {v.match.oversLimit} ov</span>
                  </p>
                  <p className="mt-2 text-sm text-fg">
                    {v.result
                      ? v.result
                      : v.current
                        ? `${v.current.runs}/${v.current.wickets} (${formatOvers(v.current.legalBalls)})`
                        : "Toss pending"}
                  </p>
                </div>
                <ArrowRight className="size-4 shrink-0 text-faint" />
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
