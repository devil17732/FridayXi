import { createFileRoute } from "@tanstack/react-router";
import { Plus, Trash2 } from "lucide-react";
import { useMemo, useState } from "react";
import { RoleBadge } from "@/components/role-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { formatCredits, ROLE_NAME } from "@/lib/cricket/format";
import type { Player, Role } from "@/lib/cricket/types";
import { useCricketStore } from "@/lib/store";

export const Route = createFileRoute("/squad")({ component: SquadPage });

const ROLES: Role[] = ["WK", "BAT", "AR", "BOWL"];

function SquadPage() {
  const players = useCricketStore((s) => s.players);
  const addPlayer = useCricketStore((s) => s.addPlayer);
  const updatePlayer = useCricketStore((s) => s.updatePlayer);
  const removePlayer = useCricketStore((s) => s.removePlayer);
  const restoreDemoSquad = useCricketStore((s) => s.restoreDemoSquad);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Player | null>(null);
  const [filter, setFilter] = useState<Role | "ALL">("ALL");

  const visible = useMemo(
    () =>
      players
        .filter((p) => filter === "ALL" || p.role === filter)
        .sort((a, b) => b.credits - a.credits || a.name.localeCompare(b.name)),
    [players, filter],
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl tracking-tight">Squad</h1>
          <p className="mt-1 text-sm text-muted">
            Price players like Dream11. Better players cost more credits.
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={restoreDemoSquad}>
            Restore demo
          </Button>
          <Button
            onClick={() => {
              setEditing(null);
              setOpen(true);
            }}
          >
            <Plus />
            Add player
          </Button>
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        {(["ALL", ...ROLES] as const).map((role) => (
          <Button
            key={role}
            size="sm"
            variant={filter === role ? "default" : "outline"}
            onClick={() => setFilter(role)}
          >
            {role === "ALL" ? "All" : ROLE_NAME[role]}
          </Button>
        ))}
      </div>

      {visible.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center text-sm text-muted">
            No players in this role. Add your Friday regulars.
          </CardContent>
        </Card>
      ) : (
        <ul className="grid gap-2">
          {visible.map((p) => (
            <li key={p.id}>
              <button
                type="button"
                onClick={() => {
                  setEditing(p);
                  setOpen(true);
                }}
                className="flex w-full items-center gap-3 rounded-xl border border-border bg-surface px-4 py-3 text-left transition-colors duration-150 hover:bg-surface-2"
              >
                <div className="flex size-10 items-center justify-center rounded-lg bg-surface-2 font-display text-sm">
                  {formatCredits(p.credits)}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate font-medium">{p.name}</p>
                  <p className="text-xs text-muted">{ROLE_NAME[p.role]}</p>
                </div>
                <RoleBadge role={p.role} />
              </button>
            </li>
          ))}
        </ul>
      )}

      <PlayerDialog
        open={open}
        onOpenChange={setOpen}
        player={editing}
        onSave={(data) => {
          if (editing) updatePlayer(editing.id, data);
          else addPlayer(data);
          setOpen(false);
        }}
        onDelete={
          editing
            ? () => {
                removePlayer(editing.id);
                setOpen(false);
              }
            : undefined
        }
      />
    </div>
  );
}

function PlayerDialog({
  open,
  onOpenChange,
  player,
  onSave,
  onDelete,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  player: Player | null;
  onSave: (data: { name: string; role: Role; credits: number }) => void;
  onDelete?: () => void;
}) {
  const [name, setName] = useState("");
  const [role, setRole] = useState<Role>("BAT");
  const [credits, setCredits] = useState("8.0");

  const reset = (p: Player | null) => {
    setName(p?.name ?? "");
    setRole(p?.role ?? "BAT");
    setCredits(p ? p.credits.toFixed(1) : "8.0");
  };

  return (
    <Dialog
      open={open}
      onOpenChange={(v) => {
        if (v) reset(player);
        onOpenChange(v);
      }}
    >
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{player ? "Edit player" : "Add player"}</DialogTitle>
          <DialogDescription>
            Credits from 4.0 to 12.0. Keep stars expensive so sides stay fair.
          </DialogDescription>
        </DialogHeader>
        <form
          className="space-y-4"
          onSubmit={(e) => {
            e.preventDefault();
            const n = name.trim();
            const c = Number(credits);
            if (!n || Number.isNaN(c)) return;
            onSave({
              name: n,
              role,
              credits: Math.min(12, Math.max(4, Math.round(c * 2) / 2)),
            });
          }}
        >
          <div className="space-y-1.5">
            <Label htmlFor="name">Name</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
              autoFocus
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Role</Label>
              <Select value={role} onValueChange={(v) => setRole(v as Role)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {ROLES.map((r) => (
                    <SelectItem key={r} value={r}>
                      {ROLE_NAME[r]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="credits">Credits</Label>
              <Input
                id="credits"
                type="number"
                min={4}
                max={12}
                step={0.5}
                value={credits}
                onChange={(e) => setCredits(e.target.value)}
                required
              />
            </div>
          </div>
          <div className="flex items-center justify-between gap-2 pt-2">
            {onDelete ? (
              <Button type="button" variant="ghost" onClick={onDelete}>
                <Trash2 />
                Remove
              </Button>
            ) : (
              <span />
            )}
            <Button type="submit">{player ? "Save" : "Add to squad"}</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
