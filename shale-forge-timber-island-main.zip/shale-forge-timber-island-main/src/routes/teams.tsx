import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Shuffle } from "lucide-react";
import { CreditMeter } from "@/components/credit-meter";
import { RoleBadge } from "@/components/role-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  creditSum,
  roleCounts,
  roleLimits,
  roleWarnings,
} from "@/lib/cricket/balance";
import { formatCredits } from "@/lib/cricket/format";
import type { Player, Role, TeamSide } from "@/lib/cricket/types";
import { useCricketStore, type Destination } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/teams")({ component: TeamsPage });

function TeamsPage() {
  const players = useCricketStore((s) => s.players);
  const selectedIds = useCricketStore((s) => s.selectedIds);
  const teamAIds = useCricketStore((s) => s.teamAIds);
  const teamBIds = useCricketStore((s) => s.teamBIds);
  const teamAName = useCricketStore((s) => s.teamAName);
  const teamBName = useCricketStore((s) => s.teamBName);
  const teamSize = useCricketStore((s) => s.teamSize);
  const budget = useCricketStore((s) => s.budget);
  const toggleSelected = useCricketStore((s) => s.toggleSelected);
  const selectAllPlaying = useCricketStore((s) => s.selectAllPlaying);
  const setTeamName = useCricketStore((s) => s.setTeamName);
  const setTeamSize = useCricketStore((s) => s.setTeamSize);
  const setBudget = useCricketStore((s) => s.setBudget);
  const balanceTeams = useCricketStore((s) => s.balanceTeams);
  const movePlayer = useCricketStore((s) => s.movePlayer);

  const byId = new Map(players.map((p) => [p.id, p]));
  const teamA = teamAIds.map((id) => byId.get(id)).filter((p): p is Player => Boolean(p));
  const teamB = teamBIds.map((id) => byId.get(id)).filter((p): p is Player => Boolean(p));
  const placed = new Set([...teamAIds, ...teamBIds]);
  const bench = players.filter((p) => selectedIds.includes(p.id) && !placed.has(p.id));
  const unused = players.filter((p) => !selectedIds.includes(p.id));
  const diff = Math.abs(creditSum(teamA) - creditSum(teamB));
  const limits = roleLimits(teamSize);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl tracking-tight">Sides</h1>
          <p className="mt-1 max-w-xl text-sm text-muted">
            Each XI spends a credit cap. Auto-balance snakes the expensive
            players so Friday stays competitive.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button onClick={balanceTeams}>
            <Shuffle />
            Auto-balance
          </Button>
          <Button asChild variant="secondary">
            <Link to="/matches">
              Create match
              <ArrowRight />
            </Link>
          </Button>
        </div>
      </div>

      <Card>
        <CardContent className="grid gap-4 p-5 sm:grid-cols-3">
          <div className="space-y-1.5">
            <Label htmlFor="size">Players per side</Label>
            <Input
              id="size"
              type="number"
              min={6}
              max={11}
              value={teamSize}
              onChange={(e) => setTeamSize(Math.min(11, Math.max(6, Number(e.target.value) || 11)))}
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="budget">Credit cap</Label>
            <Input
              id="budget"
              type="number"
              min={50}
              max={150}
              step={5}
              value={budget}
              onChange={(e) => setBudget(Number(e.target.value) || 100)}
            />
          </div>
          <div className="flex items-end">
            <p className="text-sm text-muted">
              Credit gap{" "}
              <span className="font-medium tabular-nums text-fg">{diff.toFixed(1)}</span>
            </p>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-4 lg:grid-cols-2">
        <TeamColumn
          side="A"
          name={teamAName}
          onName={(n) => setTeamName("A", n)}
          players={teamA}
          budget={budget}
          teamSize={teamSize}
          onMove={movePlayer}
        />
        <TeamColumn
          side="B"
          name={teamBName}
          onName={(n) => setTeamName("B", n)}
          players={teamB}
          budget={budget}
          teamSize={teamSize}
          onMove={movePlayer}
        />
      </div>

      <section className="space-y-3">
        <div className="flex items-center justify-between gap-3">
          <h2 className="font-display text-xl tracking-tight">Playing today</h2>
          <Button size="sm" variant="ghost" onClick={selectAllPlaying}>
            Select all
          </Button>
        </div>
        <p className="text-sm text-muted">
          Tap a name to include them in the pool. Auto-balance picks{" "}
          {teamSize * 2} from this list.
        </p>
        <ul className="grid gap-2 sm:grid-cols-2">
          {[...bench, ...unused].map((p) => {
            const on = selectedIds.includes(p.id);
            return (
              <li key={p.id}>
                <div
                  className={cn(
                    "flex items-center gap-2 rounded-xl border px-3 py-2",
                    on ? "border-border bg-surface" : "border-transparent bg-surface-2/50 opacity-60",
                  )}
                >
                  <button
                    type="button"
                    className="min-w-0 flex-1 text-left"
                    onClick={() => toggleSelected(p.id)}
                  >
                    <span className="block truncate text-sm font-medium">{p.name}</span>
                    <span className="text-xs text-muted">
                      {p.role} · {formatCredits(p.credits)}
                    </span>
                  </button>
                  {on ? (
                    <div className="flex gap-1">
                      <Button size="sm" variant="outline" onClick={() => movePlayer(p.id, "A")}>
                        A
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => movePlayer(p.id, "B")}>
                        B
                      </Button>
                    </div>
                  ) : null}
                </div>
              </li>
            );
          })}
        </ul>
      </section>

      <p className="text-xs text-faint">
        Role bands for an XI: WK {limits.WK.min}–{limits.WK.max}, BAT {limits.BAT.min}–
        {limits.BAT.max}, AR {limits.AR.min}–{limits.AR.max}, BOWL {limits.BOWL.min}–
        {limits.BOWL.max}.
      </p>
    </div>
  );
}

function TeamColumn({
  side,
  name,
  onName,
  players,
  budget,
  teamSize,
  onMove,
}: {
  side: TeamSide;
  name: string;
  onName: (n: string) => void;
  players: Player[];
  budget: number;
  teamSize: number;
  onMove: (id: string, to: Destination) => void;
}) {
  const counts = roleCounts(players);
  const warnings = roleWarnings(players, teamSize);
  const other: Destination = side === "A" ? "B" : "A";

  return (
    <Card>
      <CardContent className="space-y-4 p-5">
        <Input
          value={name}
          onChange={(e) => onName(e.target.value)}
          aria-label={`Team ${side} name`}
        />
        <CreditMeter used={creditSum(players)} budget={budget} />
        <div className="flex flex-wrap gap-2 text-xs text-muted">
          {(Object.keys(counts) as Role[]).map((role) => (
            <span key={role} className="rounded-full bg-surface-2 px-2 py-1 tabular-nums">
              {role} {counts[role]}
            </span>
          ))}
          <span className="rounded-full bg-surface-2 px-2 py-1 tabular-nums">
            {players.length}/{teamSize}
          </span>
        </div>
        {warnings.length > 0 ? (
          <p className="text-xs text-danger">{warnings.join(" · ")}</p>
        ) : (
          <p className="text-xs text-accent">Role mix looks legal</p>
        )}
        <ul className="space-y-1.5">
          {players.map((p) => (
            <li
              key={p.id}
              className="flex items-center gap-2 rounded-lg bg-surface-2 px-3 py-2"
            >
              <span className="w-10 tabular-nums text-xs text-muted">
                {formatCredits(p.credits)}
              </span>
              <span className="min-w-0 flex-1 truncate text-sm">{p.name}</span>
              <RoleBadge role={p.role} />
              <button
                type="button"
                className="text-xs text-muted hover:text-fg"
                onClick={() => onMove(p.id, other)}
              >
                Swap
              </button>
              <button
                type="button"
                className="text-xs text-muted hover:text-fg"
                onClick={() => onMove(p.id, "bench")}
              >
                Out
              </button>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  );
}
